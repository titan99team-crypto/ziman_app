# Ziman release rules. Flutter and Firebase publish their own keep rules.
# Keep Tesseract JNI bridges if the OCR package needs reflection/JNI lookup.
-keep class com.googlecode.tesseract.android.** { *; }
-dontwarn com.googlecode.tesseract.android.**
