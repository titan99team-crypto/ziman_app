package com.titan.ziman

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
