# Ziman Translation Backend v0.5

هذا الخادم هو الطبقة التي تتصل بمزود الذكاء الاصطناعي. لا تضع `OPENAI_API_KEY` داخل Flutter أو APK.

## تشغيل محلي
1. انسخ `.env.example` إلى `.env`.
2. ضع `OPENAI_API_KEY` في `.env`.
3. من مجلد `backend`:
   - `python -m venv .venv`
   - فعّل البيئة.
   - `pip install -r requirements.txt`
   - `uvicorn app.main:app --reload --port 8080`
4. Android Emulator يتصل افتراضياً إلى `http://10.0.2.2:8080`.
5. جهاز Android حقيقي يحتاج عنوان IP محلي للحاسوب أو HTTPS URL منشوراً على الإنترنت.

## إنتاج
شغّل الخادم خلف HTTPS، أضف Rate Limiting وحساب مستخدم/Device Attestation قبل الإطلاق العام، وسجّل المقاييس بدون الاحتفاظ بالنصوص الشخصية الخام إلا إذا أعطى المستخدم موافقة واضحة.

## تغيير النموذج
غيّر `ZIMAN_MODEL` في الخادم فقط؛ التطبيق لا يحتاج تحديثاً.

## التحقق من شراء الكورس — Google Play
الكورس منتج One-time / non-consumable ومعرّفه:
`ziman_kurdish_course_full`

الخادم يحتوي endpoint:
`POST /v1/entitlements/google-play/verify`

الإعدادات المطلوبة:
- `ZIMAN_ANDROID_PACKAGE_NAME`: package name الحقيقي للتطبيق المنشور.
- `GOOGLE_PLAY_SERVICE_ACCOUNT_FILE`: مسار JSON لحساب خدمة Google Cloud الممنوح صلاحية الوصول للتطبيق في Play Console.

الخادم يستخدم `purchases.productsv2.getproductpurchasev2` للتحقق من Purchase Token، ويتأكد أن الحالة `PURCHASED` وأن line item يحتوي معرّف الكورس قبل إعادة الاستحقاق `course_full`.

مهم: النسخة الحالية لا تحتوي نظام حساب مستخدم بعد. قبل الإنتاج اربط الاستحقاق بـ user_id في قاعدة بيانات الخادم حتى تبقى الملكية آمنة ومتزامنة بين أجهزة المستخدم.
