from app.schemas import HealthResponse

def test_health_default_ok():
    data = HealthResponse()
    assert data.ok is True
