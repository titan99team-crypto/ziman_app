import json
import os
from openai import OpenAI

from .prompts import SYSTEM_INSTRUCTIONS, build_user_prompt
from .schemas import TranslateRequest, TranslateResponse


class AITranslator:
    def __init__(self) -> None:
        self.client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
        self.model = os.environ.get('ZIMAN_MODEL', 'gpt-5.6-luna')

    def translate(self, request: TranslateRequest) -> TranslateResponse:
        if request.source_language == request.target_language:
            return TranslateResponse(
                translation=request.text,
                confidence=1.0,
                source='same-language',
            )

        response = self.client.responses.create(
            model=self.model,
            instructions=SYSTEM_INSTRUCTIONS,
            input=build_user_prompt(
                request.text,
                request.source_language,
                request.target_language,
                request.register,
            ),
        )

        raw = (response.output_text or '').strip()
        if raw.startswith('```'):
            raw = raw.strip('`')
            if raw.startswith('json'):
                raw = raw[4:].lstrip()

        data = json.loads(raw)
        return TranslateResponse(
            translation=str(data['translation']).strip(),
            alternative=_optional(data.get('alternative')),
            literal=_optional(data.get('literal')),
            note=_optional(data.get('note')),
            confidence=float(data.get('confidence', 0.72)),
            source=f'online-ai:{self.model}',
            needs_review=bool(data.get('needs_review', False)),
        )


def _optional(value):
    if value is None:
        return None
    value = str(value).strip()
    return value or None
