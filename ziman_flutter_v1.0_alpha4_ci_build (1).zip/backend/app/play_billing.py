import os
from dataclasses import dataclass

from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account


ANDROID_PUBLISHER_SCOPE = 'https://www.googleapis.com/auth/androidpublisher'
COURSE_PRODUCT_ID = 'ziman_kurdish_course_full'


@dataclass(frozen=True)
class VerifiedPurchase:
    verified: bool
    entitlement: str | None = None
    order_id: str | None = None
    test_purchase: bool = False


class GooglePlayVerifier:
    """Server-side verification for Google Play one-time products.

    The mobile client sends the purchase token. Credentials stay only on the
    server and must belong to a service account granted access in Play Console.
    """

    def __init__(self) -> None:
        self.package_name = os.getenv('ZIMAN_ANDROID_PACKAGE_NAME', '').strip()
        self.credentials_file = os.getenv('GOOGLE_PLAY_SERVICE_ACCOUNT_FILE', '').strip()

    @property
    def configured(self) -> bool:
        return bool(self.package_name and self.credentials_file)

    def verify(self, *, token: str, expected_product_id: str) -> VerifiedPurchase:
        if not self.configured:
            raise RuntimeError('google_play_verifier_not_configured')
        if expected_product_id != COURSE_PRODUCT_ID:
            return VerifiedPurchase(verified=False)

        credentials = service_account.Credentials.from_service_account_file(
            self.credentials_file,
            scopes=[ANDROID_PUBLISHER_SCOPE],
        )
        session = AuthorizedSession(credentials)
        url = (
            'https://androidpublisher.googleapis.com/androidpublisher/v3/'
            f'applications/{self.package_name}/purchases/productsv2/tokens/{token}'
        )
        response = session.get(url, timeout=12)
        if response.status_code != 200:
            return VerifiedPurchase(verified=False)

        payload = response.json()
        state = (payload.get('purchaseStateContext') or {}).get('purchaseState')
        line_items = payload.get('productLineItem') or []
        product_ids = {str(item.get('productId', '')) for item in line_items}
        purchased = state == 'PURCHASED' and expected_product_id in product_ids
        return VerifiedPurchase(
            verified=purchased,
            entitlement='course_full' if purchased else None,
            order_id=payload.get('orderId'),
            test_purchase=bool(payload.get('testPurchaseContext')),
        )
