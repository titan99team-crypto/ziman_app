from typing import Literal
from pydantic import BaseModel, Field, field_validator

LanguageCode = Literal['iraqi', 'sorani', 'kurmanji']


class TranslateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=1200)
    source_language: LanguageCode
    target_language: LanguageCode
    register: Literal['colloquial', 'neutral'] = 'colloquial'

    @field_validator('text')
    @classmethod
    def clean_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError('empty text')
        return value


class TranslateResponse(BaseModel):
    translation: str
    alternative: str | None = None
    literal: str | None = None
    note: str | None = None
    confidence: float = Field(ge=0, le=1)
    source: str = 'online-ai'
    needs_review: bool = False


class HealthResponse(BaseModel):
    status: str = 'ok'
    service: str = 'ziman-api'
    version: str = '0.9.0'


class UsageStatusResponse(BaseModel):
    authenticated: bool
    remaining_minute: int
    remaining_day: int
    minute_limit: int
    day_limit: int
    reset_minute_seconds: int
    reset_day_seconds: int


class GooglePlayVerifyRequest(BaseModel):
    product_id: str = Field(min_length=1, max_length=200)
    purchase_id: str | None = Field(default=None, max_length=300)
    verification_data: str = Field(min_length=1, max_length=5000)
    source: str = Field(min_length=1, max_length=50)


class EntitlementVerifyResponse(BaseModel):
    verified: bool
    entitlement: str | None = None
    order_id: str | None = None
    test_purchase: bool = False
