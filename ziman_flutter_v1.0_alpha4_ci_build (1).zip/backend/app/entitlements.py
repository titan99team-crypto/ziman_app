import hashlib
from datetime import datetime, timezone

from fastapi import HTTPException
from google.cloud import firestore as google_firestore

from .auth import firebase_server
from .play_billing import VerifiedPurchase


class EntitlementStore:
    """Binds a verified Play purchase token to exactly one Firebase UID."""

    def grant_course(self, *, uid: str, purchase_token: str, purchase: VerifiedPurchase) -> None:
        if not firebase_server.configured:
            raise HTTPException(status_code=503, detail='قاعدة بيانات الاستحقاقات غير مهيأة.')
        if not purchase.verified or purchase.entitlement != 'course_full':
            raise HTTPException(status_code=400, detail='عملية الشراء غير صالحة لفتح الكورس.')

        token_hash = hashlib.sha256(purchase_token.encode('utf-8')).hexdigest()
        db = firebase_server.db
        token_ref = db.collection('purchase_tokens').document(token_hash)
        user_ref = db.collection('users').document(uid)
        entitlement_ref = user_ref.collection('entitlements').document('course_full')
        transaction = db.transaction()

        @google_firestore.transactional
        def _grant(txn):
            token_snap = token_ref.get(transaction=txn)
            if token_snap.exists:
                linked_uid = (token_snap.to_dict() or {}).get('uid')
                if linked_uid and linked_uid != uid:
                    raise HTTPException(
                        status_code=409,
                        detail='عملية الشراء هذه مرتبطة بحساب Ziman آخر.',
                    )

            now = datetime.now(timezone.utc)
            txn.set(token_ref, {
                'uid': uid,
                'product_id': 'ziman_kurdish_course_full',
                'order_id': purchase.order_id,
                'test_purchase': purchase.test_purchase,
                'verified_at': now,
            }, merge=True)
            txn.set(entitlement_ref, {
                'active': True,
                'source': 'google_play',
                'product_id': 'ziman_kurdish_course_full',
                'order_id': purchase.order_id,
                'test_purchase': purchase.test_purchase,
                'granted_at': now,
            }, merge=True)
            # Keep the compatibility flag used by the current Flutter profile.
            txn.set(user_ref, {
                'course_full': True,
                'updated_at': now,
            }, merge=True)

        _grant(transaction)


entitlement_store = EntitlementStore()
