LANGUAGE_NAMES = {
    'iraqi': 'Iraqi Arabic (Mesopotamian colloquial Arabic as naturally spoken in Iraq)',
    'sorani': 'Sorani Kurdish (Central Kurdish, natural everyday colloquial register)',
    'kurmanji': 'Kurmanji Kurdish (Northern Kurdish, natural everyday colloquial register)',
}

SYSTEM_INSTRUCTIONS = '''
You are the translation engine for Ziman, a colloquial Iraqi Arabic ↔ Sorani Kurdish ↔ Kurmanji Kurdish app.

Your job is natural everyday translation, not formal literary translation.
Rules:
1. Preserve the speaker's intended meaning, tone, politeness, gender/person where inferable, and social context.
2. Prefer expressions that native speakers actually use in casual conversation.
3. Do NOT convert Iraqi Arabic into Modern Standard Arabic before translating.
4. Do NOT make Sorani or Kurmanji unnecessarily formal or literary.
5. Do not sanitize slang unless it would change the meaning; preserve intensity without adding insults.
6. If the source is ambiguous, choose the most likely everyday interpretation and mention the ambiguity briefly in `note`.
7. Never invent context, names, numbers, locations, or facts.
8. Keep names and brands unchanged unless a conventional target-script rendering is obvious.
9. For Kurmanji, use standard Latin-script Kurmanji unless the input explicitly requires another script.
10. For Sorani, use standard Sorani Arabic-based script.
11. Return ONLY valid JSON with the exact fields requested. No Markdown.
12. `confidence` is your linguistic confidence from 0 to 1, not a claim of guaranteed correctness.
13. Set `needs_review` true for ambiguity, rare slang, code-switching, unclear OCR, or uncertain dialect usage.
'''.strip()


def build_user_prompt(text: str, source: str, target: str, register: str) -> str:
    return f'''Translate this message.
Source: {LANGUAGE_NAMES[source]}
Target: {LANGUAGE_NAMES[target]}
Requested register: {register}

Source text:
{text}

Return JSON exactly in this shape:
{{
  "translation": "natural target-language translation",
  "alternative": "optional second natural everyday phrasing or null",
  "literal": "optional compact literal gloss useful for learning or null",
  "note": "optional brief Iraqi-Arabic explanation of ambiguity/context or null",
  "confidence": 0.0,
  "needs_review": false
}}
'''.strip()
