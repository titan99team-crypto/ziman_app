import hashlib
import os

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from dotenv import load_dotenv

from .auth import AuthenticatedUser, firebase_server, optional_user, required_user
from .entitlements import entitlement_store
from .play_billing import GooglePlayVerifier
from .rate_limiter import rate_limiter
from .schemas import (
    EntitlementVerifyResponse,
    GooglePlayVerifyRequest,
    HealthResponse,
    TranslateRequest,
    TranslateResponse,
    UsageStatusResponse,
)
from .translator import AITranslator
from .usage import usage_logger

load_dotenv()

app = FastAPI(title='Ziman API', version='1.0.0-alpha.1')
translator = AITranslator()
play_verifier = GooglePlayVerifier()


def _check_client(client: str | None) -> None:
    allowed = {item.strip() for item in os.getenv('ZIMAN_ALLOWED_CLIENTS', '').split(',') if item.strip()}
    if allowed and client not in allowed:
        raise HTTPException(status_code=403, detail='عميل غير مصرح به.')


def _network_principal(request: Request) -> str:
    # Trust proxy headers only when the deployment explicitly opts in.
    host = request.client.host if request.client else 'unknown'
    if os.getenv('ZIMAN_TRUST_PROXY_HEADERS', '0') == '1':
        forwarded = request.headers.get('x-forwarded-for', '').split(',')[0].strip()
        if forwarded:
            host = forwarded
    salt = os.getenv('ZIMAN_NETWORK_HASH_SECRET', 'ziman-dev-network-secret')
    return 'guest:' + hashlib.sha256(f'{salt}:{host}'.encode()).hexdigest()[:32]


@app.get('/health', response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse()


@app.get('/v1/usage/status', response_model=UsageStatusResponse)
def usage_status(
    request: Request,
    x_ziman_client: str | None = Header(default=None),
    user: AuthenticatedUser | None = Depends(optional_user),
) -> UsageStatusResponse:
    _check_client(x_ziman_client)
    principal = f'user:{user.uid}' if user else _network_principal(request)
    state = rate_limiter.status(principal=principal, signed_in=user is not None)
    return UsageStatusResponse(authenticated=user is not None, **state)


@app.post('/v1/translate', response_model=TranslateResponse)
def translate(
    payload: TranslateRequest,
    request: Request,
    response: Response,
    x_ziman_client: str | None = Header(default=None),
    user: AuthenticatedUser | None = Depends(optional_user),
) -> TranslateResponse:
    _check_client(x_ziman_client)
    principal = f'user:{user.uid}' if user else _network_principal(request)
    decision = rate_limiter.check(principal=principal, signed_in=user is not None)
    response.headers['X-RateLimit-Remaining-Minute'] = str(decision.remaining_minute)
    response.headers['X-RateLimit-Remaining-Day'] = str(decision.remaining_day)
    if not decision.allowed:
        headers = {'Retry-After': str(decision.retry_after_seconds)} if decision.retry_after_seconds else None
        raise HTTPException(
            status_code=429,
            detail='وصلت إلى حد الترجمة المجانية حالياً. حاول لاحقاً.',
            headers=headers,
        )

    try:
        result = translator.translate(payload)
        usage_logger.log_translation(
            principal=principal,
            signed_in=user is not None,
            source_language=payload.source_language,
            target_language=payload.target_language,
            text_length=len(payload.text),
            source=result.source,
            success=True,
            needs_review=result.needs_review,
        )
        return result
    except HTTPException:
        raise
    except Exception:
        usage_logger.log_translation(
            principal=principal,
            signed_in=user is not None,
            source_language=payload.source_language,
            target_language=payload.target_language,
            text_length=len(payload.text),
            source='provider-error',
            success=False,
        )
        raise HTTPException(status_code=502, detail='تعذر إكمال الترجمة الذكية حالياً. حاول مرة أخرى.')


@app.post('/v1/entitlements/google-play/verify', response_model=EntitlementVerifyResponse)
def verify_google_play_entitlement(
    payload: GooglePlayVerifyRequest,
    x_ziman_client: str | None = Header(default=None),
    user: AuthenticatedUser = Depends(required_user),
) -> EntitlementVerifyResponse:
    _check_client(x_ziman_client)
    if payload.source.lower() not in {'google_play', 'googleplay'}:
        raise HTTPException(status_code=400, detail='مصدر الشراء غير مدعوم.')
    if not play_verifier.configured:
        raise HTTPException(status_code=503, detail='التحقق من Google Play غير مهيأ على الخادم.')
    try:
        result = play_verifier.verify(
            token=payload.verification_data,
            expected_product_id=payload.product_id,
        )
        if result.verified:
            entitlement_store.grant_course(
                uid=user.uid,
                purchase_token=payload.verification_data,
                purchase=result,
            )
        return EntitlementVerifyResponse(
            verified=result.verified,
            entitlement=result.entitlement,
            order_id=result.order_id,
            test_purchase=result.test_purchase,
        )
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=502, detail='تعذر التحقق من عملية الشراء حالياً.')
