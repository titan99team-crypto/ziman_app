import os
import threading
import time
from dataclasses import dataclass

try:
    import redis
except Exception:  # pragma: no cover - development fallback
    redis = None


@dataclass(frozen=True)
class RateLimitDecision:
    allowed: bool
    remaining_minute: int
    remaining_day: int
    retry_after_seconds: int = 0


class RateLimiter:
    """Two-level limiter: burst/minute + daily quota.

    Redis is used in production when REDIS_URL is set. A process-local fallback
    exists only so development can run without infrastructure.
    """

    def __init__(self) -> None:
        self.redis_url = os.getenv('REDIS_URL', '').strip()
        self.guest_per_minute = int(os.getenv('ZIMAN_GUEST_PER_MINUTE', '6'))
        self.guest_per_day = int(os.getenv('ZIMAN_GUEST_PER_DAY', '40'))
        self.user_per_minute = int(os.getenv('ZIMAN_USER_PER_MINUTE', '20'))
        self.user_per_day = int(os.getenv('ZIMAN_USER_PER_DAY', '250'))
        self._redis = None
        if self.redis_url and redis is not None:
            try:
                self._redis = redis.Redis.from_url(self.redis_url, decode_responses=True)
                self._redis.ping()
            except Exception:
                self._redis = None
        self._lock = threading.Lock()
        self._local: dict[str, tuple[int, float]] = {}

    @property
    def distributed(self) -> bool:
        return self._redis is not None

    def check(self, *, principal: str, signed_in: bool) -> RateLimitDecision:
        per_minute = self.user_per_minute if signed_in else self.guest_per_minute
        per_day = self.user_per_day if signed_in else self.guest_per_day
        now = int(time.time())
        minute_bucket = now // 60
        day_bucket = now // 86400
        minute_key = f'ziman:rl:m:{principal}:{minute_bucket}'
        day_key = f'ziman:rl:d:{principal}:{day_bucket}'
        sec_to_minute = max(1, 60 - (now % 60))
        sec_to_day = max(1, 86400 - (now % 86400))

        minute_count = self._increment(minute_key, sec_to_minute + 2)
        day_count = self._increment(day_key, sec_to_day + 2)
        allowed = minute_count <= per_minute and day_count <= per_day
        retry = 0
        if minute_count > per_minute:
            retry = sec_to_minute
        elif day_count > per_day:
            retry = sec_to_day
        return RateLimitDecision(
            allowed=allowed,
            remaining_minute=max(0, per_minute - minute_count),
            remaining_day=max(0, per_day - day_count),
            retry_after_seconds=retry,
        )


    def status(self, *, principal: str, signed_in: bool) -> dict[str, int]:
        per_minute = self.user_per_minute if signed_in else self.guest_per_minute
        per_day = self.user_per_day if signed_in else self.guest_per_day
        now = int(time.time())
        minute_bucket = now // 60
        day_bucket = now // 86400
        minute_key = f'ziman:rl:m:{principal}:{minute_bucket}'
        day_key = f'ziman:rl:d:{principal}:{day_bucket}'
        minute_count = self._get(minute_key)
        day_count = self._get(day_key)
        return {
            'remaining_minute': max(0, per_minute - minute_count),
            'remaining_day': max(0, per_day - day_count),
            'minute_limit': per_minute,
            'day_limit': per_day,
            'reset_minute_seconds': max(1, 60 - (now % 60)),
            'reset_day_seconds': max(1, 86400 - (now % 86400)),
        }

    def _get(self, key: str) -> int:
        if self._redis is not None:
            raw = self._redis.get(key)
            return int(raw) if raw is not None else 0
        now = time.time()
        with self._lock:
            current, expires = self._local.get(key, (0, now))
            if expires <= now:
                return 0
            return current

    def _increment(self, key: str, ttl: int) -> int:
        if self._redis is not None:
            script = """
            local current = redis.call('INCR', KEYS[1])
            if current == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]) end
            return current
            """
            return int(self._redis.eval(script, 1, key, ttl))

        now = time.time()
        with self._lock:
            current, expires = self._local.get(key, (0, now + ttl))
            if expires <= now:
                current, expires = 0, now + ttl
            current += 1
            self._local[key] = (current, expires)
            if len(self._local) > 10000:
                self._local = {k: v for k, v in self._local.items() if v[1] > now}
            return current


rate_limiter = RateLimiter()
