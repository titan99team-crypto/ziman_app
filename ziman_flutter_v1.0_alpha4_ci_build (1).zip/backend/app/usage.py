import hashlib
import hmac
import os
from datetime import datetime, timezone
from uuid import uuid4

from .auth import firebase_server


class UsageLogger:
    """Privacy-minimized operational telemetry.

    Source text and translated text are deliberately NOT logged here.
    """

    def __init__(self) -> None:
        self.secret = os.getenv('ZIMAN_USAGE_HASH_SECRET', '').encode('utf-8')
        self.enabled = os.getenv('ZIMAN_USAGE_LOGGING', '1') == '1'

    def pseudonym(self, value: str) -> str:
        key = self.secret or b'ziman-dev-change-me'
        return hmac.new(key, value.encode('utf-8'), hashlib.sha256).hexdigest()[:32]

    def log_translation(
        self,
        *,
        principal: str,
        signed_in: bool,
        source_language: str,
        target_language: str,
        text_length: int,
        source: str,
        success: bool,
        needs_review: bool = False,
    ) -> None:
        if not self.enabled or not firebase_server.configured:
            return
        event = {
            'event': 'translation',
            'principal_hash': self.pseudonym(principal),
            'signed_in': signed_in,
            'source_language': source_language,
            'target_language': target_language,
            'text_length': text_length,
            'translation_source': source,
            'success': success,
            'needs_review': needs_review,
            'created_at': datetime.now(timezone.utc),
        }
        try:
            firebase_server.db.collection('usage_events').document(str(uuid4())).set(event)
        except Exception:
            # Telemetry must never break translation.
            pass


usage_logger = UsageLogger()
