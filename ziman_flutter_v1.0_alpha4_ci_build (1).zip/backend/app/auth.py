import os
from dataclasses import dataclass
from typing import Optional

import firebase_admin
from fastapi import Header, HTTPException
from firebase_admin import auth, credentials, firestore


@dataclass(frozen=True)
class AuthenticatedUser:
    uid: str
    email: str | None = None
    phone_number: str | None = None


class FirebaseServer:
    """Initializes Firebase Admin once and verifies mobile Firebase ID tokens."""

    def __init__(self) -> None:
        self._app = None
        self._db = None
        self._init_error: str | None = None
        self._initialize()

    def _initialize(self) -> None:
        if firebase_admin._apps:
            self._app = firebase_admin.get_app()
            self._db = firestore.client(self._app)
            return
        try:
            credentials_file = os.getenv('FIREBASE_SERVICE_ACCOUNT_FILE', '').strip()
            project_id = os.getenv('FIREBASE_PROJECT_ID', '').strip() or None
            options = {'projectId': project_id} if project_id else None
            if credentials_file:
                cred = credentials.Certificate(credentials_file)
                self._app = firebase_admin.initialize_app(cred, options=options)
            else:
                # Works with Application Default Credentials on Cloud Run/GCP.
                self._app = firebase_admin.initialize_app(options=options)
            self._db = firestore.client(self._app)
        except Exception as exc:
            self._init_error = type(exc).__name__

    @property
    def configured(self) -> bool:
        return self._app is not None and self._db is not None

    @property
    def db(self):
        if self._db is None:
            raise RuntimeError('firebase_admin_not_configured')
        return self._db

    def verify_bearer(self, authorization: str | None, *, required: bool) -> Optional[AuthenticatedUser]:
        if not authorization:
            if required:
                raise HTTPException(status_code=401, detail='يجب تسجيل الدخول لإكمال هذه العملية.')
            return None
        if not authorization.lower().startswith('bearer '):
            raise HTTPException(status_code=401, detail='رمز المصادقة غير صالح.')
        if not self.configured:
            raise HTTPException(status_code=503, detail='مصادقة Firebase غير مهيأة على الخادم.')

        token = authorization.split(' ', 1)[1].strip()
        if not token:
            raise HTTPException(status_code=401, detail='رمز المصادقة مفقود.')
        try:
            decoded = auth.verify_id_token(
                token,
                app=self._app,
                check_revoked=os.getenv('ZIMAN_CHECK_REVOKED_TOKENS', '0') == '1',
            )
        except auth.RevokedIdTokenError:
            raise HTTPException(status_code=401, detail='انتهت صلاحية الجلسة. سجّل الدخول من جديد.')
        except Exception:
            raise HTTPException(status_code=401, detail='تعذر التحقق من هوية المستخدم.')

        uid = str(decoded.get('uid') or decoded.get('sub') or '').strip()
        if not uid:
            raise HTTPException(status_code=401, detail='هوية المستخدم غير صالحة.')
        return AuthenticatedUser(
            uid=uid,
            email=decoded.get('email'),
            phone_number=decoded.get('phone_number'),
        )


firebase_server = FirebaseServer()


def optional_user(authorization: str | None = Header(default=None)) -> Optional[AuthenticatedUser]:
    return firebase_server.verify_bearer(authorization, required=False)


def required_user(authorization: str | None = Header(default=None)) -> AuthenticatedUser:
    user = firebase_server.verify_bearer(authorization, required=True)
    assert user is not None
    return user
