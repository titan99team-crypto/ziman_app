class AppConfig {
  /// Configure at build time:
  /// flutter run --dart-define=ZIMAN_API_BASE_URL=https://api.example.com
  static const apiBaseUrl = String.fromEnvironment(
    'ZIMAN_API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080',
  );

  /// Optional public app identifier. Never place provider secrets here.
  static const appClientId = String.fromEnvironment(
    'ZIMAN_APP_CLIENT_ID',
    defaultValue: 'ziman-mobile-dev',
  );

  static const requestTimeoutSeconds = 18;
}
