import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/translation_result.dart';
import 'auth_service.dart';

class OnlineTranslationException implements Exception {
  final String message;
  final int? statusCode;
  const OnlineTranslationException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class OnlineTranslationService {
  final http.Client client;
  final String baseUrl;

  OnlineTranslationService({http.Client? client, String? baseUrl})
      : client = client ?? http.Client(),
        baseUrl = baseUrl ?? AppConfig.apiBaseUrl;

  Future<TranslationResult> translate({
    required String text,
    required String from,
    required String to,
  }) async {
    final uri = Uri.parse('$baseUrl/v1/translate');
    try {
      final idToken = await AuthService().idToken();
      final response = await client
          .post(
            uri,
            headers: {
              'content-type': 'application/json; charset=utf-8',
              'accept': 'application/json',
              'x-ziman-client': AppConfig.appClientId,
              if (idToken != null) 'authorization': 'Bearer $idToken',
            },
            body: jsonEncode({
              'text': text,
              'source_language': from,
              'target_language': to,
              'register': 'colloquial',
            }),
          )
          .timeout(const Duration(seconds: AppConfig.requestTimeoutSeconds));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        String message = response.statusCode == 429
            ? 'وصلت إلى حد الترجمة المجانية حالياً. جرّب لاحقاً.'
            : 'تعذر الاتصال بمحرك الترجمة.';
        try {
          final body = jsonDecode(utf8.decode(response.bodyBytes));
          if (body is Map && body['detail'] is String) message = body['detail'];
        } catch (_) {}
        throw OnlineTranslationException(message, statusCode: response.statusCode);
      }

      final body = jsonDecode(utf8.decode(response.bodyBytes));
      if (body is! Map<String, dynamic>) {
        throw const OnlineTranslationException('استجابة الخادم غير صالحة.');
      }

      final primary = (body['translation'] as String?)?.trim() ?? '';
      if (primary.isEmpty) {
        throw const OnlineTranslationException('الخادم لم يرجع ترجمة.');
      }

      final rawConfidence = body['confidence'];
      final confidence = rawConfidence is num
          ? rawConfidence.toDouble().clamp(0.0, 1.0)
          : 0.72;

      return TranslationResult(
        primary: primary,
        alternative: (body['alternative'] as String?)?.trim().isEmpty == false
            ? (body['alternative'] as String).trim()
            : null,
        literal: (body['literal'] as String?)?.trim().isEmpty == false
            ? (body['literal'] as String).trim()
            : null,
        note: (body['note'] as String?)?.trim().isEmpty == false
            ? (body['note'] as String).trim()
            : null,
        confidence: confidence,
        source: (body['source'] as String?) ?? 'online-ai',
        needsReview: body['needs_review'] == true,
      );
    } on TimeoutException {
      throw const OnlineTranslationException('انتهت مهلة الاتصال. جرّب مرة أخرى.');
    } on OnlineTranslationException {
      rethrow;
    } catch (_) {
      throw const OnlineTranslationException('لا يوجد اتصال صالح بمحرك Ziman حالياً.');
    }
  }

  void dispose() => client.close();
}
