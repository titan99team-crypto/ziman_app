import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/usage_status.dart';
import 'auth_service.dart';

class UsageStatusService {
  final http.Client _client;
  UsageStatusService({http.Client? client}) : _client = client ?? http.Client();

  Future<UsageStatus> fetch() async {
    final token = await AuthService().idToken();
    final response = await _client.get(
      Uri.parse('${AppConfig.apiBaseUrl}/v1/usage/status'),
      headers: {
        'accept': 'application/json',
        'x-ziman-client': AppConfig.appClientId,
        if (token != null) 'authorization': 'Bearer $token',
      },
    ).timeout(const Duration(seconds: AppConfig.requestTimeoutSeconds));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('تعذر جلب حالة الاستخدام.');
    }
    final body = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    return UsageStatus(
      authenticated: body['authenticated'] == true,
      remainingMinute: (body['remaining_minute'] as num?)?.toInt() ?? 0,
      remainingDay: (body['remaining_day'] as num?)?.toInt() ?? 0,
      minuteLimit: (body['minute_limit'] as num?)?.toInt() ?? 0,
      dayLimit: (body['day_limit'] as num?)?.toInt() ?? 0,
      resetMinuteSeconds: (body['reset_minute_seconds'] as num?)?.toInt() ?? 0,
      resetDaySeconds: (body['reset_day_seconds'] as num?)?.toInt() ?? 0,
    );
  }

  void dispose() => _client.close();
}
