import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/dialect_entry.dart';
import 'text_normalizer.dart';

class DialectMatch {
  final DialectEntry entry;
  final double score;
  const DialectMatch(this.entry, this.score);
}

class DialectRepository {
  final TextNormalizer normalizer;
  List<DialectEntry>? _entries;

  DialectRepository({TextNormalizer? normalizer})
      : normalizer = normalizer ?? const TextNormalizer();

  Future<List<DialectEntry>> _load() async {
    if (_entries != null) return _entries!;
    final raw = await rootBundle.loadString('assets/data/dialect_phrases.json');
    final list = jsonDecode(raw) as List<dynamic>;
    _entries = list
        .map((e) => DialectEntry.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
    return _entries!;
  }

  Future<DialectMatch?> find({
    required String input,
    required String from,
    required String to,
  }) async {
    final entries = await _load();
    final normalizedInput = normalizer.normalize(input);
    if (normalizedInput.isEmpty) return null;

    DialectMatch? best;
    for (final entry in entries) {
      if (!entry.text.containsKey(from) || !entry.text.containsKey(to)) continue;

      final candidates = <String>{
        entry.text[from]!,
        ...?entry.variants[from],
      };

      for (final candidate in candidates) {
        final score = _similarity(
          normalizedInput,
          normalizer.normalize(candidate),
        );
        if (best == null || score > best.score) {
          best = DialectMatch(entry, score);
        }
      }
    }

    if (best == null || best.score < 0.72) return null;
    return best;
  }

  double _similarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.contains(b) || b.contains(a)) {
      final minLen = a.length < b.length ? a.length : b.length;
      final maxLen = a.length > b.length ? a.length : b.length;
      return 0.86 + (0.12 * minLen / maxLen);
    }

    final aTokens = a.split(' ').where((e) => e.isNotEmpty).toSet();
    final bTokens = b.split(' ').where((e) => e.isNotEmpty).toSet();
    if (aTokens.isEmpty || bTokens.isEmpty) return 0;
    final intersection = aTokens.intersection(bTokens).length;
    final union = aTokens.union(bTokens).length;
    return intersection / union;
  }
}
