import 'package:shared_preferences/shared_preferences.dart';

class CourseProgressService {
  static const _completedKey = 'course_completed_lessons_v1';
  static const _scorePrefix = 'course_score_';
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  Future<Set<String>> completedLessonIds() async {
    final values = await _prefs.getStringList(_completedKey) ?? const <String>[];
    return values.toSet();
  }

  Future<void> markCompleted(String lessonId, {int? score}) async {
    final completed = await completedLessonIds();
    completed.add(lessonId);
    await _prefs.setStringList(_completedKey, completed.toList()..sort());
    if (score != null) await _prefs.setInt('$_scorePrefix$lessonId', score.clamp(0, 100));
  }

  Future<int?> scoreFor(String lessonId) => _prefs.getInt('$_scorePrefix$lessonId');

  Future<Map<String, int>> scoresFor(Iterable<String> lessonIds) async {
    final out = <String, int>{};
    for (final id in lessonIds) {
      final score = await scoreFor(id);
      if (score != null) out[id] = score;
    }
    return out;
  }

  Future<void> mergeRemote({required Iterable<String> completed, required Map<String, dynamic> scores}) async {
    final local = await completedLessonIds();
    local.addAll(completed);
    await _prefs.setStringList(_completedKey, local.toList()..sort());
    for (final entry in scores.entries) {
      final value = entry.value;
      if (value is int) {
        final current = await scoreFor(entry.key) ?? 0;
        if (value > current) await _prefs.setInt('$_scorePrefix${entry.key}', value.clamp(0, 100));
      }
    }
  }

  Future<double> completionRatio(Iterable<String> allLessonIds) async {
    final all = allLessonIds.toSet();
    if (all.isEmpty) return 0;
    final completed = await completedLessonIds();
    return completed.intersection(all).length / all.length;
  }
}
