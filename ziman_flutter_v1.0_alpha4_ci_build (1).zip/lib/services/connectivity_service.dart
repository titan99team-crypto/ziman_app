import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class ConnectivitySnapshot {
  final bool hasNetworkInterface;
  final List<ConnectivityResult> results;
  const ConnectivitySnapshot(this.hasNetworkInterface, this.results);

  String get label {
    if (!hasNetworkInterface) return 'غير متصل';
    if (results.contains(ConnectivityResult.wifi)) return 'Wi‑Fi';
    if (results.contains(ConnectivityResult.mobile)) return 'بيانات الهاتف';
    if (results.contains(ConnectivityResult.ethernet)) return 'Ethernet';
    return 'متصل بالشبكة';
  }
}

class ConnectivityService {
  final Connectivity _connectivity = Connectivity();

  Stream<ConnectivitySnapshot> get changes => _connectivity.onConnectivityChanged.map(_map);

  Future<ConnectivitySnapshot> current() async => _map(await _connectivity.checkConnectivity());

  ConnectivitySnapshot _map(List<ConnectivityResult> results) {
    final connected = results.any((e) => e != ConnectivityResult.none);
    return ConnectivitySnapshot(connected, results);
  }
}
