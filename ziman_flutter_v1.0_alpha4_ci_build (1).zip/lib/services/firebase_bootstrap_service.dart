import 'package:firebase_core/firebase_core.dart';

class FirebaseBootstrapService {
  static bool _ready = false;
  static String? _error;

  static bool get ready => _ready;
  static String? get error => _error;

  static Future<void> initialize() async {
    if (_ready) return;
    try {
      await Firebase.initializeApp();
      _ready = true;
      _error = null;
    } catch (e) {
      _ready = false;
      _error = e.toString();
    }
  }
}
