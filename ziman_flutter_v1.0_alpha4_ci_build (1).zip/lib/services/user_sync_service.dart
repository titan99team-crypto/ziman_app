import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/user_profile.dart';
import 'firebase_bootstrap_service.dart';

class UserSyncService {
  FirebaseFirestore? get _db => FirebaseBootstrapService.ready ? FirebaseFirestore.instance : null;
  User? get _user => FirebaseBootstrapService.ready ? FirebaseAuth.instance.currentUser : null;

  DocumentReference<Map<String, dynamic>>? get _userRef {
    final db = _db;
    final user = _user;
    if (db == null || user == null) return null;
    return db.collection('users').doc(user.uid);
  }

  Future<UserProfile?> ensureProfile() async {
    final user = _user;
    final ref = _userRef;
    if (user == null || ref == null) return null;
    final snap = await ref.get();
    if (!snap.exists) {
      final profile = UserProfile(
        uid: user.uid,
        displayName: user.displayName?.trim().isNotEmpty == true ? user.displayName!.trim() : 'مستخدم Ziman',
        email: user.email,
        phone: user.phoneNumber,
        photoUrl: user.photoURL,
      );
      await ref.set(profile.toMap(), SetOptions(merge: true));
      return profile;
    }
    return UserProfile.fromMap(snap.data()!..['uid'] = user.uid);
  }

  Stream<UserProfile?> watchProfile() {
    final ref = _userRef;
    if (ref == null) return Stream<UserProfile?>.value(null);
    return ref.snapshots().map((snap) {
      final data = snap.data();
      if (data == null) return null;
      data['uid'] = snap.id;
      return UserProfile.fromMap(data);
    });
  }

  Future<void> updatePreferredLanguage(String code) async {
    await _userRef?.set({'preferred_learning_language': code, 'updated_at_ms': DateTime.now().millisecondsSinceEpoch}, SetOptions(merge: true));
  }

  Future<void> pushProgress({required Set<String> completed, required Map<String, int> scores}) async {
    final ref = _userRef;
    if (ref == null) return;
    await ref.collection('learning').doc('progress').set({
      'completed_lessons': completed.toList()..sort(),
      'scores': scores,
      'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
    }, SetOptions(merge: true));
  }

  Future<Map<String, dynamic>?> pullProgress() async {
    final ref = _userRef;
    if (ref == null) return null;
    final snap = await ref.collection('learning').doc('progress').get();
    return snap.data();
  }
}
