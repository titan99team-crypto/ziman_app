import 'dart:async';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_error.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceListenResult {
  final String text;
  final bool isFinal;
  final double confidence;

  const VoiceListenResult({
    required this.text,
    required this.isFinal,
    required this.confidence,
  });
}

class VoiceCapability {
  final bool available;
  final String? localeId;
  final String message;

  const VoiceCapability({
    required this.available,
    this.localeId,
    required this.message,
  });
}

/// Device speech-recognition adapter.
///
/// Important: speech_to_text uses the speech recognizer installed on the
/// device. Kurdish locale availability therefore differs by Android/iOS
/// version, vendor, installed language packs and user settings.
class VoiceRecognitionService {
  final SpeechToText _speech = SpeechToText();
  bool _initialized = false;
  List<LocaleName> _locales = const [];

  bool get isListening => _speech.isListening;

  Future<bool> initialize({
    void Function(String status)? onStatus,
    void Function(String error)? onError,
  }) async {
    if (_initialized) return true;
    final ok = await _speech.initialize(
      onStatus: onStatus,
      onError: (SpeechRecognitionError e) => onError?.call(e.errorMsg),
      debugLogging: false,
    );
    _initialized = ok;
    if (ok) {
      _locales = await _speech.locales();
    }
    return ok;
  }

  Future<VoiceCapability> capabilityFor(String languageCode) async {
    final ok = await initialize();
    if (!ok) {
      return const VoiceCapability(
        available: false,
        message: 'خدمة التعرف على الصوت غير متاحة على هذا الجهاز.',
      );
    }
    final locale = _bestLocale(languageCode);
    if (locale == null) {
      return VoiceCapability(
        available: false,
        message: 'لا توجد حزمة تعرف صوت مناسبة لهذه اللهجة على الجهاز حالياً.',
      );
    }
    return VoiceCapability(
      available: true,
      localeId: locale.localeId,
      message: 'جاهز للاستماع عبر ${locale.name}.',
    );
  }

  Future<VoiceCapability> listen({
    required String languageCode,
    required void Function(VoiceListenResult result) onResult,
    void Function(String status)? onStatus,
    void Function(String error)? onError,
  }) async {
    final ok = await initialize(onStatus: onStatus, onError: onError);
    if (!ok) {
      return const VoiceCapability(
        available: false,
        message: 'تعذر تشغيل خدمة التعرف على الصوت.',
      );
    }

    final locale = _bestLocale(languageCode);
    if (locale == null) {
      return const VoiceCapability(
        available: false,
        message: 'لغة التعرف الصوتي المطلوبة غير مثبتة على الجهاز.',
      );
    }

    await _speech.listen(
      onResult: (SpeechRecognitionResult r) {
        onResult(VoiceListenResult(
          text: r.recognizedWords,
          isFinal: r.finalResult,
          confidence: r.confidence,
        ));
      },
      localeId: locale.localeId,
      listenFor: const Duration(seconds: 45),
      pauseFor: const Duration(seconds: 4),
      partialResults: true,
      cancelOnError: true,
      listenMode: ListenMode.dictation,
    );

    return VoiceCapability(
      available: true,
      localeId: locale.localeId,
      message: 'أستمع الآن… احچي بصورة طبيعية.',
    );
  }

  Future<void> stop() => _speech.stop();
  Future<void> cancel() => _speech.cancel();

  LocaleName? _bestLocale(String languageCode) {
    final candidates = switch (languageCode) {
      'iraqi' => const ['ar_IQ', 'ar-IQ', 'ar'],
      'sorani' => const ['ckb_IQ', 'ckb-IQ', 'ckb', 'ku_IQ', 'ku-IQ', 'ku'],
      'kurmanji' => const ['ku_TR', 'ku-TR', 'ku_IQ', 'ku-IQ', 'ku'],
      _ => const <String>[],
    };

    for (final wanted in candidates) {
      for (final locale in _locales) {
        if (_normalizeLocale(locale.localeId) == _normalizeLocale(wanted)) {
          return locale;
        }
      }
    }

    // Last-resort language-prefix match; useful because engines use
    // underscore/hyphen and region tags inconsistently.
    for (final wanted in candidates) {
      final prefix = _normalizeLocale(wanted).split('-').first;
      for (final locale in _locales) {
        if (_normalizeLocale(locale.localeId).split('-').first == prefix) {
          return locale;
        }
      }
    }
    return null;
  }

  String _normalizeLocale(String value) => value.toLowerCase().replaceAll('_', '-');
}

class TextToSpeechService {
  final FlutterTts _tts = FlutterTts();
  List<String>? _languages;
  bool _configured = false;

  Future<void> _configure() async {
    if (_configured) return;
    await _tts.setSpeechRate(0.44);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
    await _tts.awaitSpeakCompletion(true);
    _configured = true;
  }

  Future<VoiceCapability> capabilityFor(String languageCode) async {
    await _configure();
    final language = await _bestLanguage(languageCode);
    if (language == null) {
      return const VoiceCapability(
        available: false,
        message: 'لا يوجد صوت مناسب لهذه اللغة مثبت على الجهاز.',
      );
    }
    return VoiceCapability(
      available: true,
      localeId: language,
      message: 'الصوت متوفر: $language',
    );
  }

  Future<VoiceCapability> speak({
    required String text,
    required String languageCode,
  }) async {
    if (text.trim().isEmpty) {
      return const VoiceCapability(available: false, message: 'لا يوجد نص لقراءته.');
    }
    await _configure();
    final language = await _bestLanguage(languageCode);
    if (language == null) {
      return const VoiceCapability(
        available: false,
        message: 'لا يوجد صوت مناسب لهذه اللغة على الجهاز. يمكننا لاحقاً استخدام مزود صوت سحابي مخصص.',
      );
    }
    await _tts.stop();
    await _tts.setLanguage(language);
    await _tts.speak(text);
    return VoiceCapability(
      available: true,
      localeId: language,
      message: 'تم تشغيل النطق.',
    );
  }

  Future<void> stop() => _tts.stop();

  Future<String?> _bestLanguage(String languageCode) async {
    final raw = await _tts.getLanguages;
    _languages ??= (raw as List<dynamic>).map((e) => e.toString()).toList(growable: false);
    final candidates = switch (languageCode) {
      'iraqi' => const ['ar-IQ', 'ar_IQ', 'ar'],
      'sorani' => const ['ckb-IQ', 'ckb_IQ', 'ckb', 'ku-IQ', 'ku_IQ', 'ku'],
      'kurmanji' => const ['ku-TR', 'ku_TR', 'ku-IQ', 'ku_IQ', 'ku'],
      _ => const <String>[],
    };

    for (final wanted in candidates) {
      for (final installed in _languages!) {
        if (_normalizeLocale(installed) == _normalizeLocale(wanted)) return installed;
      }
    }
    for (final wanted in candidates) {
      final prefix = _normalizeLocale(wanted).split('-').first;
      for (final installed in _languages!) {
        if (_normalizeLocale(installed).split('-').first == prefix) return installed;
      }
    }
    return null;
  }

  String _normalizeLocale(String value) => value.toLowerCase().replaceAll('_', '-');
}
