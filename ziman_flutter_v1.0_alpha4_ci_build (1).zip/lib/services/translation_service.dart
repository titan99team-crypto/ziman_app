import '../models/translation_result.dart';
import 'dialect_repository.dart';
import 'online_translation_service.dart';

abstract class TranslationService {
  Future<TranslationResult> translate({
    required String text,
    required String from,
    required String to,
  });
}

/// Ziman production translation resolution order:
/// 1) Curated local colloquial corpus (fast, reviewed phrases win).
/// 2) Online intelligent translation backend.
/// 3) Offline fallback message until the dedicated on-device model is added.
///
/// Provider secrets never live in the mobile app.
class HybridTranslationService implements TranslationService {
  final DialectRepository repository;
  final OnlineTranslationService online;

  HybridTranslationService({
    DialectRepository? repository,
    OnlineTranslationService? online,
  })  : repository = repository ?? DialectRepository(),
        online = online ?? OnlineTranslationService();

  @override
  Future<TranslationResult> translate({
    required String text,
    required String from,
    required String to,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) {
      return const TranslationResult(
        primary: '',
        confidence: 0,
        source: 'empty',
      );
    }

    if (from == to) {
      return TranslationResult(
        primary: clean,
        confidence: 1,
        source: 'same-language',
        note: 'لغة المصدر والهدف متطابقة.',
      );
    }

    final match = await repository.find(input: clean, from: from, to: to);
    if (match != null && match.score >= 0.92) {
      final entry = match.entry;
      return TranslationResult(
        primary: entry.text[to]!,
        alternative: entry.alternatives[to],
        literal: entry.literal[to],
        note: entry.note.isEmpty ? null : entry.note,
        confidence: entry.humanReviewed
            ? (0.96 * match.score).clamp(0.0, 0.99)
            : (0.84 * match.score).clamp(0.0, 0.92),
        source: entry.humanReviewed ? 'curated-reviewed' : 'curated-seed',
        needsReview: !entry.humanReviewed,
      );
    }

    try {
      return await online.translate(text: clean, from: from, to: to);
    } on OnlineTranslationException catch (e) {
      // A weaker local match is better than nothing when offline, but make the
      // uncertainty explicit to the user.
      if (match != null) {
        final entry = match.entry;
        return TranslationResult(
          primary: entry.text[to]!,
          alternative: entry.alternatives[to],
          literal: entry.literal[to],
          note: 'نتيجة محلية تقريبية لأن الاتصال بالخادم غير متاح. ${e.message}',
          confidence: (0.62 * match.score).clamp(0.0, 0.72),
          source: 'offline-approximate',
          needsReview: true,
        );
      }

      return TranslationResult(
        primary: 'تعذر إجراء الترجمة الذكية الآن.',
        alternative: 'تحقق من الإنترنت أو حمّل حزمة الترجمة Offline عند توفرها.',
        note: e.message,
        confidence: 0,
        source: 'offline-unresolved',
        needsReview: true,
      );
    }
  }
}
