import 'dart:io';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import '../models/ocr_result.dart';

abstract class OcrService {
  Future<OcrResult> extractText({
    required String imagePath,
    required String languageCode,
  });
}

/// Local OCR engine used by Ziman.
///
/// It intentionally keeps OCR separate from translation. The OCR layer only
/// extracts what exists in the image; the colloquial translation layer decides
/// how that text should be expressed in Iraqi/Sorani/Kurmanji.
class TesseractOcrService implements OcrService {
  @override
  Future<OcrResult> extractText({
    required String imagePath,
    required String languageCode,
  }) async {
    final language = _tesseractLanguage(languageCode);
    try {
      final text = await FlutterTesseractOcr.extractText(
        imagePath,
        language: language,
        args: const {
          'psm': '6',
          'preserve_interword_spaces': '1',
        },
      );

      final cleaned = _clean(text);
      return OcrResult(
        text: cleaned,
        engine: 'tesseract-local',
        language: language,
        confidence: cleaned.isEmpty ? 0 : 0.70,
        offline: true,
        note: 'الدقة تعتمد على وضوح الصورة ونموذج اللغة المثبت. النص الناتج يحتاج مراجعة قبل الاعتماد النهائي.',
      );
    } catch (e) {
      throw OcrException(_friendlyError(e.toString(), language));
    }
  }

  String _tesseractLanguage(String code) => switch (code) {
        'iraqi' => 'ara',
        // Sorani uses Arabic-derived script. Running both models gives us a
        // practical local baseline until a Sorani-specific model is trained.
        'sorani' => 'ara+kur',
        'kurmanji' => 'kur',
        _ => 'ara',
      };

  String _clean(String value) => value
      .replaceAll('\u0000', '')
      .replaceAll(RegExp(r'[ \t]+'), ' ')
      .replaceAll(RegExp(r'\n{3,}'), '\n\n')
      .trim();

  String _friendlyError(String raw, String language) {
    final lower = raw.toLowerCase();
    if (lower.contains('traineddata') || lower.contains('tessdata')) {
      return 'حزمة OCR المطلوبة ($language) غير مثبتة بعد. نزّل حزمة اللغة ثم أعد المحاولة.';
    }
    return 'تعذر قراءة النص من الصورة محلياً: $raw';
  }
}

class OcrException implements Exception {
  final String message;
  const OcrException(this.message);
  @override
  String toString() => message;
}

/// Downloads official Tesseract language packs once, then OCR works offline.
/// In production these files should be mirrored on Ziman's own CDN and pinned
/// by checksum/version instead of depending permanently on GitHub raw URLs.
class OcrLanguagePackService {
  static const _base =
      'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main';

  static const Map<String, String> packLabels = {
    'ara': 'العربية / العراقي',
    'kur': 'الكردية',
  };

  Future<String> _dir() => FlutterTesseractOcr.getTessdataPath();

  Future<OcrPackState> state(String code) async {
    final dir = await _dir();
    final file = File('$dir/$code.traineddata');
    return OcrPackState(
      code: code,
      installed: await file.exists(),
      label: packLabels[code] ?? code,
      path: file.path,
    );
  }

  Future<List<OcrPackState>> states() async {
    return Future.wait(packLabels.keys.map(state));
  }

  Future<void> download(
    String code, {
    void Function(int received, int? total)? onProgress,
  }) async {
    if (!packLabels.containsKey(code)) {
      throw OcrException('حزمة OCR غير معروفة: $code');
    }

    final dir = await _dir();
    final target = File('$dir/$code.traineddata');
    await target.parent.create(recursive: true);
    final temp = File('${target.path}.part');

    final client = HttpClient();
    try {
      final request = await client.getUrl(Uri.parse('$_base/$code.traineddata'));
      request.headers.set(HttpHeaders.userAgentHeader, 'Ziman/0.4');
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw OcrException('فشل تنزيل الحزمة (HTTP ${response.statusCode}).');
      }

      final total = response.contentLength > 0 ? response.contentLength : null;
      var received = 0;
      final sink = temp.openWrite();
      await for (final chunk in response) {
        received += chunk.length;
        sink.add(chunk);
        onProgress?.call(received, total);
      }
      await sink.close();

      // A traineddata file is much larger than a few KB. This catches HTML
      // error pages or interrupted downloads before replacing a valid model.
      if (!await temp.exists() || await temp.length() < 100000) {
        if (await temp.exists()) await temp.delete();
        throw const OcrException('ملف الحزمة الذي تم تنزيله غير صالح أو ناقص.');
      }

      if (await target.exists()) await target.delete();
      await temp.rename(target.path);
    } finally {
      client.close(force: true);
    }
  }

  Future<void> remove(String code) async {
    final dir = await _dir();
    final file = File('$dir/$code.traineddata');
    if (await file.exists()) await file.delete();
  }
}
