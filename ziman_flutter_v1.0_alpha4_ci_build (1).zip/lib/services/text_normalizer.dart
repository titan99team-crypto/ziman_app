class TextNormalizer {
  const TextNormalizer();

  static const Map<String, String> _arabicCharMap = {
    'أ': 'ا',
    'إ': 'ا',
    'آ': 'ا',
    'ى': 'ي',
    'ؤ': 'و',
    'ئ': 'ي',
    'ـ': '',
  };

  String normalize(String input) {
    var text = input.trim().toLowerCase();
    for (final entry in _arabicCharMap.entries) {
      text = text.replaceAll(entry.key, entry.value);
    }

    text = text
        .replaceAll(RegExp(r'[؟?!.،,:;؛"“”()]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return text;
  }
}
