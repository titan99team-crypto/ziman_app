import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:in_app_purchase/in_app_purchase.dart';

import '../config/app_config.dart';
import 'auth_service.dart';

class PurchaseService extends ChangeNotifier {
  static const courseProductId = 'ziman_kurdish_course_full';
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  bool storeAvailable = false;
  bool loading = true;
  bool purchased = false;
  String? message;
  ProductDetails? courseProduct;

  String get displayPrice => courseProduct?.price ?? r'$10';

  Future<void> initialize() async {
    _subscription ??= _iap.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (Object error) {
        message = 'حدث خطأ أثناء متابعة عملية الشراء.';
        notifyListeners();
      },
    );

    try {
      storeAvailable = await _iap.isAvailable();
      if (!storeAvailable) {
        message = 'متجر Google Play غير متاح على هذا الجهاز.';
        loading = false;
        notifyListeners();
        return;
      }
      final response = await _iap.queryProductDetails({courseProductId});
      if (response.productDetails.isNotEmpty) {
        courseProduct = response.productDetails.first;
      } else {
        message = 'لم يتم العثور على منتج الكورس. أنشئه في Play Console بالمعرّف $courseProductId.';
      }
    } catch (_) {
      message = 'تعذر الاتصال بمتجر Google Play حالياً.';
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> buyCourse() async {
    final authToken = await AuthService().idToken();
    if (authToken == null) {
      message = 'سجّل الدخول أولاً حتى يرتبط شراء الكورس بحسابك بأمان.';
      notifyListeners();
      return;
    }
    final product = courseProduct;
    if (product == null) {
      message = 'الكورس غير مهيأ للبيع بعد في Google Play Console.';
      notifyListeners();
      return;
    }
    message = null;
    notifyListeners();
    await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: product));
  }

  Future<void> restore() async {
    message = 'جاري استعادة المشتريات…';
    notifyListeners();
    await _iap.restorePurchases();
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID != courseProductId) continue;

      if (purchase.status == PurchaseStatus.pending) {
        message = 'عملية الدفع قيد المعالجة…';
        notifyListeners();
        continue;
      }

      if (purchase.status == PurchaseStatus.error) {
        message = purchase.error?.message ?? 'فشلت عملية الشراء.';
        notifyListeners();
      }

      if (purchase.status == PurchaseStatus.purchased || purchase.status == PurchaseStatus.restored) {
        final verified = await _verifyWithServer(purchase);
        if (verified) {
          purchased = true;
          message = 'تم فتح الكورس الكامل.';
          if (purchase.pendingCompletePurchase) {
            await _iap.completePurchase(purchase);
          }
        } else {
          message = 'تم استلام عملية الشراء، لكن التحقق من الخادم لم يكتمل. لن نفتح المحتوى قبل التحقق الآمن.';
        }
        notifyListeners();
      }
    }
  }

  Future<bool> _verifyWithServer(PurchaseDetails purchase) async {
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/v1/entitlements/google-play/verify');
    try {
      final token = await AuthService().idToken();
      if (token == null) return false;
      final response = await http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              'X-Ziman-Client': AppConfig.appClientId,
              'Authorization': 'Bearer $token',
            },
            body: jsonEncode({
              'product_id': purchase.productID,
              'purchase_id': purchase.purchaseID,
              'verification_data': purchase.verificationData.serverVerificationData,
              'source': purchase.verificationData.source,
            }),
          )
          .timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) return false;
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      return data['verified'] == true && data['entitlement'] == 'course_full';
    } catch (_) {
      return false;
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
