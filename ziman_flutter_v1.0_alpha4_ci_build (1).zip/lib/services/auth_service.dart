import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'firebase_bootstrap_service.dart';

class AuthActionResult {
  final bool ok;
  final String message;
  const AuthActionResult(this.ok, this.message);
}

class AuthService {
  FirebaseAuth? get _auth => FirebaseBootstrapService.ready ? FirebaseAuth.instance : null;
  final GoogleSignIn _google = GoogleSignIn.instance;
  bool _googleInitialized = false;
  String? _verificationId;
  int? _resendToken;

  Stream<User?> get authStateChanges => _auth?.authStateChanges() ?? Stream<User?>.value(null);
  User? get currentUser => _auth?.currentUser;

  Future<void> _initGoogle() async {
    if (_googleInitialized) return;
    await _google.initialize();
    _googleInitialized = true;
  }

  Future<AuthActionResult> signInWithGoogle() async {
    final auth = _auth;
    if (auth == null) return const AuthActionResult(false, 'Firebase غير مهيأ بعد. راجع ملف إعداد Firebase داخل المشروع.');
    try {
      await _initGoogle();
      final account = await _google.authenticate();
      final idToken = account.authentication.idToken;
      if (idToken == null) return const AuthActionResult(false, 'لم يصل رمز Google المطلوب للمصادقة.');
      final credential = GoogleAuthProvider.credential(idToken: idToken);
      await auth.signInWithCredential(credential);
      return const AuthActionResult(true, 'تم تسجيل الدخول بحساب Google.');
    } on GoogleSignInException catch (e) {
      return AuthActionResult(false, 'تعذر تسجيل الدخول عبر Google: ${e.code.name}');
    } on FirebaseAuthException catch (e) {
      return AuthActionResult(false, e.message ?? 'تعذر تسجيل الدخول.');
    } catch (e) {
      return AuthActionResult(false, 'حدث خطأ غير متوقع أثناء تسجيل الدخول.');
    }
  }

  Future<AuthActionResult> requestPhoneCode(String phoneNumber, {bool forceResend = false}) async {
    final auth = _auth;
    if (auth == null) return const AuthActionResult(false, 'Firebase غير مهيأ بعد.');
    final completer = Completer<AuthActionResult>();
    await auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      forceResendingToken: forceResend ? _resendToken : null,
      verificationCompleted: (credential) async {
        await auth.signInWithCredential(credential);
        if (!completer.isCompleted) completer.complete(const AuthActionResult(true, 'تم التحقق من الرقم تلقائياً.'));
      },
      verificationFailed: (e) {
        if (!completer.isCompleted) completer.complete(AuthActionResult(false, e.message ?? 'تعذر إرسال رمز التحقق.'));
      },
      codeSent: (verificationId, resendToken) {
        _verificationId = verificationId;
        _resendToken = resendToken;
        if (!completer.isCompleted) completer.complete(const AuthActionResult(true, 'تم إرسال رمز التحقق.'));
      },
      codeAutoRetrievalTimeout: (verificationId) => _verificationId = verificationId,
      timeout: const Duration(seconds: 60),
    );
    return completer.future;
  }

  Future<AuthActionResult> confirmPhoneCode(String smsCode) async {
    final auth = _auth;
    final verificationId = _verificationId;
    if (auth == null) return const AuthActionResult(false, 'Firebase غير مهيأ بعد.');
    if (verificationId == null) return const AuthActionResult(false, 'أرسل رمز التحقق أولاً.');
    try {
      final credential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsCode.trim());
      await auth.signInWithCredential(credential);
      return const AuthActionResult(true, 'تم تسجيل الدخول برقم الهاتف.');
    } on FirebaseAuthException catch (e) {
      return AuthActionResult(false, e.message ?? 'رمز التحقق غير صحيح.');
    }
  }

  Future<String?> idToken() => _auth?.currentUser?.getIdToken();

  Future<void> signOut() async {
    if (_googleInitialized) {
      try { await _google.signOut(); } catch (_) {}
    }
    await _auth?.signOut();
  }
}
