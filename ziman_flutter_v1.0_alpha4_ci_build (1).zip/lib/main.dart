import 'package:flutter/material.dart';
import 'screens/app_root.dart';
import 'services/app_preferences_service.dart';
import 'services/firebase_bootstrap_service.dart';
import 'services/app_theme_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseBootstrapService.initialize();
  AppThemeController.themeMode.value = await AppPreferencesService().themeMode();
  runApp(const ZimanApp());
}


class ZimanApp extends StatelessWidget {
  const ZimanApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
    valueListenable: AppThemeController.themeMode,
    builder: (_, mode, __) {
      final light = ColorScheme.fromSeed(seedColor: const Color(0xFF4B5FE7), brightness: Brightness.light);
      final dark = ColorScheme.fromSeed(seedColor: const Color(0xFF7C8CFF), brightness: Brightness.dark);
      ThemeData theme(ColorScheme scheme) => ThemeData(
        colorScheme: scheme,
        useMaterial3: true,
        scaffoldBackgroundColor: scheme.brightness == Brightness.light ? const Color(0xFFF8F8FC) : const Color(0xFF101116),
        cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
        navigationBarTheme: NavigationBarThemeData(indicatorColor: scheme.primaryContainer),
        inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
      );
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Ziman',
        locale: const Locale('ar'),
        theme: theme(light),
        darkTheme: theme(dark),
        themeMode: mode,
        builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox()),
        home: const AppRoot(),
      );
    },
  );
}
