class TranslationResult {
  final String primary;
  final String? alternative;
  final String? literal;
  final String? note;
  final double confidence;
  final String source;
  final bool needsReview;

  const TranslationResult({
    required this.primary,
    this.alternative,
    this.literal,
    this.note,
    required this.confidence,
    required this.source,
    this.needsReview = false,
  });
}
