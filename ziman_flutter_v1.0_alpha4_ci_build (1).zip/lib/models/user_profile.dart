class UserProfile {
  final String uid;
  final String displayName;
  final String? email;
  final String? phone;
  final String? photoUrl;
  final String preferredLearningLanguage;
  final bool courseFull;
  final DateTime? updatedAt;

  const UserProfile({
    required this.uid,
    required this.displayName,
    this.email,
    this.phone,
    this.photoUrl,
    this.preferredLearningLanguage = 'sorani',
    this.courseFull = false,
    this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
        'uid': uid,
        'display_name': displayName,
        'email': email,
        'phone': phone,
        'photo_url': photoUrl,
        'preferred_learning_language': preferredLearningLanguage,
        'course_full': courseFull,
        'updated_at_ms': DateTime.now().millisecondsSinceEpoch,
      };

  factory UserProfile.fromMap(Map<String, dynamic> map) => UserProfile(
        uid: (map['uid'] ?? '') as String,
        displayName: (map['display_name'] ?? 'مستخدم Ziman') as String,
        email: map['email'] as String?,
        phone: map['phone'] as String?,
        photoUrl: map['photo_url'] as String?,
        preferredLearningLanguage: (map['preferred_learning_language'] ?? 'sorani') as String,
        courseFull: map['course_full'] == true,
        updatedAt: map['updated_at_ms'] is int
            ? DateTime.fromMillisecondsSinceEpoch(map['updated_at_ms'] as int)
            : null,
      );
}
