class OcrResult {
  final String text;
  final String engine;
  final String language;
  final double confidence;
  final bool offline;
  final String? note;

  const OcrResult({
    required this.text,
    required this.engine,
    required this.language,
    required this.confidence,
    required this.offline,
    this.note,
  });

  bool get isEmpty => text.trim().isEmpty;
}

class OcrPackState {
  final String code;
  final bool installed;
  final String label;
  final String? path;

  const OcrPackState({
    required this.code,
    required this.installed,
    required this.label,
    this.path,
  });
}
