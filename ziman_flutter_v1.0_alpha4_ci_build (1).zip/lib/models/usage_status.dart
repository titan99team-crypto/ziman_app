class UsageStatus {
  final bool authenticated;
  final int remainingMinute;
  final int remainingDay;
  final int minuteLimit;
  final int dayLimit;
  final int resetMinuteSeconds;
  final int resetDaySeconds;

  const UsageStatus({
    required this.authenticated,
    required this.remainingMinute,
    required this.remainingDay,
    required this.minuteLimit,
    required this.dayLimit,
    required this.resetMinuteSeconds,
    required this.resetDaySeconds,
  });

  double get dailyUsedFraction => dayLimit <= 0 ? 0 : ((dayLimit - remainingDay) / dayLimit).clamp(0, 1).toDouble();
}
