class LanguageOption {
  final String code;
  final String label;
  final String subtitle;
  final String flag;

  const LanguageOption({
    required this.code,
    required this.label,
    required this.subtitle,
    required this.flag,
  });
}

const supportedLanguages = <LanguageOption>[
  LanguageOption(code: 'iraqi', label: 'العراقي', subtitle: 'اللهجة العراقية', flag: '🇮🇶'),
  LanguageOption(code: 'sorani', label: 'سۆرانی', subtitle: 'کوردی سۆرانی', flag: '☀️'),
  LanguageOption(code: 'kurmanji', label: 'Kurmancî', subtitle: 'Kurdî Kurmancî', flag: '🟨'),
];
