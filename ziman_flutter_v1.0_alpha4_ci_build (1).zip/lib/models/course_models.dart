enum LessonExerciseType { phrase, dialogue, multipleChoice, listening }

class CoursePhrase {
  final String iraqi;
  final String sorani;
  final String kurmanji;
  final String note;

  const CoursePhrase({
    required this.iraqi,
    required this.sorani,
    required this.kurmanji,
    this.note = '',
  });
}

class DialogueLine {
  final String speaker;
  final String iraqi;
  final String sorani;
  final String kurmanji;

  const DialogueLine({
    required this.speaker,
    required this.iraqi,
    required this.sorani,
    required this.kurmanji,
  });
}

class QuizQuestion {
  final String prompt;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const QuizQuestion({
    required this.prompt,
    required this.options,
    required this.correctIndex,
    this.explanation = '',
  });
}

class CourseLesson {
  final String id;
  final String title;
  final String subtitle;
  final String situation;
  final int minutes;
  final bool free;
  final List<CoursePhrase> phrases;
  final List<DialogueLine> dialogue;
  final List<QuizQuestion> quiz;

  const CourseLesson({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.situation,
    required this.minutes,
    required this.free,
    required this.phrases,
    this.dialogue = const [],
    this.quiz = const [],
  });
}

class CourseLevel {
  final String id;
  final String title;
  final String description;
  final List<CourseLesson> lessons;

  const CourseLevel({
    required this.id,
    required this.title,
    required this.description,
    required this.lessons,
  });
}
