class DialectEntry {
  final String id;
  final Map<String, String> text;
  final Map<String, List<String>> variants;
  final Map<String, String> alternatives;
  final Map<String, String> literal;
  final String category;
  final String register;
  final String note;
  final bool humanReviewed;

  const DialectEntry({
    required this.id,
    required this.text,
    required this.variants,
    required this.alternatives,
    required this.literal,
    required this.category,
    required this.register,
    required this.note,
    required this.humanReviewed,
  });

  factory DialectEntry.fromJson(Map<String, dynamic> json) {
    Map<String, String> stringMap(dynamic value) =>
        (value as Map<String, dynamic>? ?? const {})
            .map((k, v) => MapEntry(k, v.toString()));

    Map<String, List<String>> listMap(dynamic value) =>
        (value as Map<String, dynamic>? ?? const {}).map(
          (k, v) => MapEntry(
            k,
            (v as List<dynamic>? ?? const []).map((e) => e.toString()).toList(),
          ),
        );

    return DialectEntry(
      id: json['id']?.toString() ?? '',
      text: stringMap(json['text']),
      variants: listMap(json['variants']),
      alternatives: stringMap(json['alternatives']),
      literal: stringMap(json['literal']),
      category: json['category']?.toString() ?? 'general',
      register: json['register']?.toString() ?? 'colloquial',
      note: json['note']?.toString() ?? '',
      humanReviewed: json['humanReviewed'] == true,
    );
  }
}
