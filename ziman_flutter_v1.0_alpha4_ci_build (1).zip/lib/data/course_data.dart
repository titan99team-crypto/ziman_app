import '../models/course_models.dart';

/// Seed curriculum for the first production-ready learning flow.
/// Kurdish wording is still marked for native-speaker editorial review before launch.
const courseLevels = <CourseLevel>[
  CourseLevel(
    id: 'starter',
    title: 'المستوى 1 — البداية اليومية',
    description: 'أول الجمل التي تحتاجها حتى تبدأ تحچي بصورة طبيعية.',
    lessons: [
      CourseLesson(
        id: 'greetings',
        title: 'التحيات والتعارف',
        subtitle: 'شلونك؟ شسمك؟ منين إنت؟',
        situation: 'لقاء شخص لأول مرة',
        minutes: 8,
        free: true,
        phrases: [
          CoursePhrase(iraqi: 'شلونك؟', sorani: 'چۆنی؟', kurmanji: 'Tu çawa yî?', note: 'تحية يومية غير رسمية.'),
          CoursePhrase(iraqi: 'زين الحمد لله.', sorani: 'باشم، سوپاس.', kurmanji: 'Baş im, spas.'),
          CoursePhrase(iraqi: 'شسمك؟', sorani: 'ناوت چییە؟', kurmanji: 'Navê te çi ye?'),
          CoursePhrase(iraqi: 'اسمي علي.', sorani: 'ناوم عەلییە.', kurmanji: 'Navê min Elî ye.'),
          CoursePhrase(iraqi: 'منين إنت؟', sorani: 'خەڵکی کوێیت؟', kurmanji: 'Tu ji ku derê yî?'),
        ],
        dialogue: [
          DialogueLine(speaker: 'أ', iraqi: 'هلا، شلونك؟', sorani: 'سڵاو، چۆنی؟', kurmanji: 'Silav, tu çawa yî?'),
          DialogueLine(speaker: 'ب', iraqi: 'هلا بيك، زين الحمد لله.', sorani: 'سڵاو، باشم سوپاس.', kurmanji: 'Silav, baş im spas.'),
          DialogueLine(speaker: 'أ', iraqi: 'شسمك؟', sorani: 'ناوت چییە؟', kurmanji: 'Navê te çi ye?'),
        ],
        quiz: [
          QuizQuestion(prompt: 'شنو المقابل السوراني الأقرب لـ «شلونك؟»', options: ['چۆنی؟', 'سوپاس', 'خوات لەگەڵ'], correctIndex: 0),
          QuizQuestion(prompt: '«Navê te çi ye?» معناها بالعراقي:', options: ['وين رايح؟', 'شسمك؟', 'شكد السعر؟'], correctIndex: 1),
        ],
      ),
      CourseLesson(
        id: 'everyday',
        title: 'جمل يومية سريعة',
        subtitle: 'هسه، بعدين، انتظر، ما أدري.',
        situation: 'حديث يومي قصير',
        minutes: 9,
        free: true,
        phrases: [
          CoursePhrase(iraqi: 'هسه أجي.', sorani: 'ئێستا دێم.', kurmanji: 'Ez niha têm.'),
          CoursePhrase(iraqi: 'انتظر شوي.', sorani: 'کەمێک چاوەڕێ بکە.', kurmanji: 'Hinek bisekine.'),
          CoursePhrase(iraqi: 'ما أدري.', sorani: 'نازانم.', kurmanji: 'Ez nizanim.'),
          CoursePhrase(iraqi: 'عادي، ماكو مشكلة.', sorani: 'ئاساییە، کێشە نییە.', kurmanji: 'Asayî ye, pirsgirêk tune.'),
        ],
        quiz: [
          QuizQuestion(prompt: '«نازانم» تقابل:', options: ['ما أدري', 'تعال', 'غالي'], correctIndex: 0),
        ],
      ),
      CourseLesson(
        id: 'market',
        title: 'السوق والأسعار',
        subtitle: 'شكد؟ غالي، رخيص، أريد هذا.',
        situation: 'شراء من السوق أو محل',
        minutes: 12,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'شكد سعره؟', sorani: 'نرخەکەی چەندە؟', kurmanji: 'Buhayê wê çend e?'),
          CoursePhrase(iraqi: 'غالي كلش.', sorani: 'زۆر گرانە.', kurmanji: 'Pir biha ye.'),
          CoursePhrase(iraqi: 'أريد هذا.', sorani: 'ئەمەم دەوێت.', kurmanji: 'Ez vê dixwazim.'),
          CoursePhrase(iraqi: 'عندك أرخص؟', sorani: 'هەرزانترت هەیە؟', kurmanji: 'Yê erzantr heye?'),
        ],
        quiz: [
          QuizQuestion(prompt: '«زۆر گرانە» معناها:', options: ['رخيص كلش', 'غالي كلش', 'ما أريده'], correctIndex: 1),
        ],
      ),
    ],
  ),
  CourseLevel(
    id: 'situations',
    title: 'المستوى 2 — المواقف الحقيقية',
    description: 'مطعم، تاكسي، اتجاهات، دوام ومواقف تستخدمها كل يوم.',
    lessons: [
      CourseLesson(
        id: 'restaurant',
        title: 'في المطعم',
        subtitle: 'الطلب، الملاحظات والحساب.',
        situation: 'طلب وجبة في مطعم',
        minutes: 14,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'أريد أطلب.', sorani: 'دەمەوێت داوا بکەم.', kurmanji: 'Ez dixwazim siparîş bikim.'),
          CoursePhrase(iraqi: 'بدون حار لو سمحت.', sorani: 'بێ تیژ، تکایە.', kurmanji: 'Ji kerema xwe bê tûj.'),
          CoursePhrase(iraqi: 'الحساب لو سمحت.', sorani: 'حیسابەکە، تکایە.', kurmanji: 'Hesab, ji kerema xwe.'),
        ],
      ),
      CourseLesson(
        id: 'taxi',
        title: 'التاكسي والاتجاهات',
        subtitle: 'يمين، يسار، قريب، بعيد.',
        situation: 'التحدث مع سائق',
        minutes: 13,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'ودّيني لهنا.', sorani: 'بمبە بۆ ئێرە.', kurmanji: 'Min bibe vir.'),
          CoursePhrase(iraqi: 'لف يمين.', sorani: 'بۆ ڕاست بپێچەوە.', kurmanji: 'Li rastê bizivire.'),
          CoursePhrase(iraqi: 'بعيد من هنا؟', sorani: 'لە ئێرەوە دوورە؟', kurmanji: 'Ji vir dûr e?'),
        ],
      ),
      CourseLesson(
        id: 'work',
        title: 'العمل والدوام',
        subtitle: 'متى تجي؟ خلصت؟ دزلي الملف.',
        situation: 'محادثة بين الزملاء',
        minutes: 15,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'متى تجي؟', sorani: 'کەی دێیت؟', kurmanji: 'Tu kengê têyî?'),
          CoursePhrase(iraqi: 'خلصت الشغل.', sorani: 'کارەکەم تەواو کرد.', kurmanji: 'Min kar qedand.'),
          CoursePhrase(iraqi: 'دزلي الملف.', sorani: 'فایلەکەم بۆ بنێرە.', kurmanji: 'Dosyayê ji min re bişîne.'),
        ],
      ),
    ],
  ),
  CourseLevel(
    id: 'conversation',
    title: 'المستوى 3 — المحادثة الطبيعية',
    description: 'ردود أسرع، تعبيرات شائعة، ومحادثات أطول بدون ترجمة حرفية.',
    lessons: [
      CourseLesson(
        id: 'plans',
        title: 'الخطط والمواعيد',
        subtitle: 'اليوم، باچر، خل نتفق.',
        situation: 'ترتيب موعد مع صديق',
        minutes: 16,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'باچر فاضي؟', sorani: 'سبەی بەتاڵیت؟', kurmanji: 'Tu sibê vala yî?'),
          CoursePhrase(iraqi: 'خل نتفق عالساعة سبعة.', sorani: 'با لە کاتژمێر حەوت ڕێک بکەوین.', kurmanji: 'Ka em li saet heftê li hev bikin.'),
          CoursePhrase(iraqi: 'إذا تأخرت دزلي.', sorani: 'ئەگەر دوا کەوتیت پەیامم بۆ بنێرە.', kurmanji: 'Heke dereng ketî, ji min re peyam bişîne.'),
        ],
      ),
      CourseLesson(
        id: 'full-dialogue',
        title: 'محادثة كاملة',
        subtitle: 'استماع، فهم، اختيار الرد المناسب.',
        situation: 'محادثة يومية متكاملة',
        minutes: 20,
        free: false,
        phrases: [
          CoursePhrase(iraqi: 'شنو السالفة؟', sorani: 'چی بووە؟', kurmanji: 'Çi bû?'),
          CoursePhrase(iraqi: 'ماكو شي، كلشي تمام.', sorani: 'هیچ نییە، هەموو شت باشە.', kurmanji: 'Tiştek tune, her tişt baş e.'),
        ],
      ),
    ],
  ),
];

List<CourseLesson> get allCourseLessons => [for (final level in courseLevels) ...level.lessons];
