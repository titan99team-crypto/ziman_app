import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/user_profile.dart';
import '../services/auth_service.dart';
import '../services/firebase_bootstrap_service.dart';
import '../services/user_sync_service.dart';
import 'settings_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _auth = AuthService();
  final _sync = UserSyncService();
  final _phone = TextEditingController(text: '+964');
  final _code = TextEditingController();
  bool busy = false;
  bool codeSent = false;
  String? message;

  @override
  void dispose() { _phone.dispose(); _code.dispose(); super.dispose(); }

  Future<void> _google() async {
    setState(() { busy = true; message = null; });
    final r = await _auth.signInWithGoogle();
    if (r.ok) await _sync.ensureProfile();
    if (mounted) setState(() { busy = false; message = r.message; });
  }

  Future<void> _sendCode() async {
    if (_phone.text.trim().length < 8) return;
    setState(() { busy = true; message = null; });
    final r = await _auth.requestPhoneCode(_phone.text.trim());
    if (mounted) setState(() { busy = false; codeSent = r.ok; message = r.message; });
  }

  Future<void> _confirm() async {
    setState(() { busy = true; message = null; });
    final r = await _auth.confirmPhoneCode(_code.text);
    if (r.ok) await _sync.ensureProfile();
    if (mounted) setState(() { busy = false; message = r.message; });
  }

  @override
  Widget build(BuildContext context) {
    if (!FirebaseBootstrapService.ready) {
      return _SetupRequired(message: FirebaseBootstrapService.error);
    }
    return StreamBuilder<User?>(
      stream: _auth.authStateChanges,
      builder: (context, snapshot) {
        final user = snapshot.data;
        if (user == null) return _signedOut(context);
        return _signedIn(context, user);
      },
    );
  }

  Widget _signedOut(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('حساب Ziman', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('سجّل الدخول حتى ينتقل تقدمك وشراء الكورس معك عند تغيير الهاتف.', style: TextStyle(color: Colors.grey)),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: busy ? null : _google, icon: const Icon(Icons.g_mobiledata_rounded), label: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('المتابعة باستخدام Google'))),
      const SizedBox(height: 18),
      const Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('أو رقم الهاتف')), Expanded(child: Divider())]),
      const SizedBox(height: 18),
      TextField(controller: _phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'رقم الهاتف', hintText: '+9647XXXXXXXXX')),
      const SizedBox(height: 10),
      OutlinedButton(onPressed: busy ? null : _sendCode, child: const Text('إرسال رمز التحقق')),
      if (codeSent) ...[
        const SizedBox(height: 12),
        TextField(controller: _code, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'رمز SMS')),
        const SizedBox(height: 10),
        FilledButton(onPressed: busy ? null : _confirm, child: const Text('تأكيد وتسجيل الدخول')),
      ],
      if (busy) const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator())),
      if (message != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(message!, textAlign: TextAlign.center)),
    ],
  );

  Widget _signedIn(BuildContext context, User user) {
    _sync.ensureProfile();
    return StreamBuilder<UserProfile?>(
      stream: _sync.watchProfile(),
      builder: (context, snap) {
        final p = snap.data;
        return ListView(padding: const EdgeInsets.all(18), children: [
          const Text('الملف الشخصي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          Center(child: CircleAvatar(radius: 42, backgroundImage: (p?.photoUrl ?? user.photoURL) != null ? NetworkImage((p?.photoUrl ?? user.photoURL)!) : null, child: (p?.photoUrl ?? user.photoURL) == null ? const Icon(Icons.person_rounded, size: 42) : null)),
          const SizedBox(height: 12),
          Text(p?.displayName ?? user.displayName ?? 'مستخدم Ziman', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          if ((p?.email ?? user.email) != null) Text(p?.email ?? user.email!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)),
          if ((p?.phone ?? user.phoneNumber) != null) Text(p?.phone ?? user.phoneNumber!, textAlign: TextAlign.center, textDirection: TextDirection.ltr),
          const SizedBox(height: 22),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            ListTile(leading: const Icon(Icons.workspace_premium_rounded), title: const Text('الكورس الكامل'), trailing: Text(p?.courseFull == true ? 'مفتوح' : 'غير مشترى', style: TextStyle(fontWeight: FontWeight.w700, color: p?.courseFull == true ? Colors.green : null))),
            const Divider(),
            DropdownButtonFormField<String>(value: p?.preferredLearningLanguage ?? 'sorani', decoration: const InputDecoration(labelText: 'لغة التعلم المفضلة', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'sorani', child: Text('السوراني')), DropdownMenuItem(value: 'kurmanji', child: Text('الكرمانجي'))], onChanged: (v) { if (v != null) _sync.updatePreferredLanguage(v); }),
          ]))),
          const SizedBox(height: 14),
          Card(child: ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('الإعدادات والخصوصية'), trailing: const Icon(Icons.chevron_left), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())))),
          const SizedBox(height: 14),
          OutlinedButton.icon(onPressed: () async { await _auth.signOut(); if (mounted) setState(() {}); }, icon: const Icon(Icons.logout_rounded), label: const Text('تسجيل الخروج')),
          const SizedBox(height: 12),
          const Text('لن نخزن تسجيلات الصوت أو الصور في الملف الشخصي بشكل افتراضي. تقدم التعلم وحالة الاستحقاق فقط هما ما تتم مزامنتهما.', style: TextStyle(fontSize: 12, color: Colors.grey), textAlign: TextAlign.center),
        ]);
      },
    );
  }
}

class _SetupRequired extends StatelessWidget {
  final String? message;
  const _SetupRequired({this.message});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Icon(Icons.cloud_off_rounded, size: 58),
    const SizedBox(height: 16),
    const Text('إعداد Firebase مطلوب', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
    const SizedBox(height: 10),
    const Text('نسخة Ziman تعمل كضيف بدون حساب، لكن لتفعيل Google/الهاتف والمزامنة نفّذ flutterfire configure وضع google-services.json داخل Android.', textAlign: TextAlign.center),
    if (message != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(message!, style: const TextStyle(fontSize: 11, color: Colors.grey), textAlign: TextAlign.center)),
  ]);
}
