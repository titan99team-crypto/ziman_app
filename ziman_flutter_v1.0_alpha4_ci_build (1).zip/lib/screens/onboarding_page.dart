import 'package:flutter/material.dart';
import '../services/app_preferences_service.dart';
import 'home_screen.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});
  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final controller = PageController();
  int index = 0;
  final prefs = AppPreferencesService();

  static const pages = [
    _OnboardingData(Icons.translate_rounded, 'احچي مثل ما تحچي يومياً', 'Ziman مصمم للعراقي والسوراني والكرمانجي المحكي، مو للترجمة الفصحى الحرفية.'),
    _OnboardingData(Icons.record_voice_over_rounded, 'نص، صوت ومحادثة', 'اكتب أو احچي، واستمع للترجمة عندما يتوفر صوت مناسب على جهازك.'),
    _OnboardingData(Icons.document_scanner_rounded, 'ترجمة من الصور', 'اقرأ النص من الكاميرا أو المعرض. حزم OCR يمكن تنزيلها حتى تعمل محلياً.'),
    _OnboardingData(Icons.school_rounded, 'تعلم اللغة من مواقف حقيقية', 'الدروس تركّز على الكلام اليومي: السوق، المطعم، العمل، السفر والمحادثات الواقعية.'),
    _OnboardingData(Icons.privacy_tip_outlined, 'خصوصيتك أولاً', 'لا نخزن نص الترجمة أو صورك أو تسجيلاتك الصوتية افتراضياً. بعض الميزات السحابية تحتاج إنترنت.'),
  ];

  Future<void> finish() async {
    await prefs.completeOnboarding();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Column(children: [
        Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: finish, child: const Text('تخطي'))),
        Expanded(child: PageView.builder(
          controller: controller,
          itemCount: pages.length,
          onPageChanged: (v) => setState(() => index = v),
          itemBuilder: (_, i) => _OnboardingSlide(data: pages[i]),
        )),
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(pages.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 220), margin: const EdgeInsets.all(4), width: i == index ? 24 : 8, height: 8, decoration: BoxDecoration(color: i == index ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outlineVariant, borderRadius: BorderRadius.circular(20))))),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: FilledButton(
              onPressed: () {
                if (index == pages.length - 1) { finish(); return; }
                controller.nextPage(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
              },
              child: Padding(padding: const EdgeInsets.symmetric(vertical: 14), child: Text(index == pages.length - 1 ? 'ابدأ استخدام Ziman' : 'التالي')),
            )),
          ]),
        ),
      ]),
    ),
  );
}

class _OnboardingData {
  final IconData icon; final String title; final String body;
  const _OnboardingData(this.icon, this.title, this.body);
}
class _OnboardingSlide extends StatelessWidget {
  final _OnboardingData data; const _OnboardingSlide({required this.data});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 30),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 112, height: 112, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(32)), child: Icon(data.icon, size: 58, color: Theme.of(context).colorScheme.primary)),
      const SizedBox(height: 34),
      Text(data.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 14),
      Text(data.body, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, height: 1.75, color: Theme.of(context).colorScheme.onSurfaceVariant)),
    ]),
  );
}
