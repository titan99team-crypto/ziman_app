import 'package:flutter/material.dart';
import '../models/usage_status.dart';
import '../services/usage_status_service.dart';

class UsagePage extends StatefulWidget { const UsagePage({super.key}); @override State<UsagePage> createState()=>_UsagePageState(); }
class _UsagePageState extends State<UsagePage> {
  final service=UsageStatusService(); Future<UsageStatus>? future;
  @override void initState(){super.initState(); future=service.fetch();}
  @override void dispose(){service.dispose();super.dispose();}
  void reload()=>setState(()=>future=service.fetch());
  String duration(int s){ if(s>=3600) return '${(s/3600).ceil()} ساعة'; if(s>=60) return '${(s/60).ceil()} دقيقة'; return '$s ثانية'; }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حدود الاستخدام')),body:FutureBuilder<UsageStatus>(future:future,builder:(context,s){
    if(s.connectionState==ConnectionState.waiting) return const Center(child:CircularProgressIndicator());
    if(s.hasError) return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.cloud_off_rounded,size:54),const SizedBox(height:12),const Text('تعذر جلب حدود الاستخدام.'),const SizedBox(height:12),OutlinedButton.icon(onPressed:reload,icon:const Icon(Icons.refresh),label:const Text('إعادة المحاولة'))])));
    final u=s.data!;
    return RefreshIndicator(onRefresh:() async=>reload(),child:ListView(padding:const EdgeInsets.all(18),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(u.authenticated?'حساب مسجل':'وضع الضيف',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(u.authenticated?'لديك حد أعلى مرتبط بحسابك.':'سجّل الدخول للحصول على حد يومي أعلى وحفظ تقدمك.',style:const TextStyle(color:Colors.grey))]))),
      const SizedBox(height:14),
      _Quota(title:'اليوم',remaining:u.remainingDay,total:u.dayLimit,reset:'يتجدد خلال ${duration(u.resetDaySeconds)}'),
      const SizedBox(height:12),
      _Quota(title:'هذه الدقيقة',remaining:u.remainingMinute,total:u.minuteLimit,reset:'يتجدد خلال ${duration(u.resetMinuteSeconds)}'),
      const SizedBox(height:18),
      const Text('هذه الحدود تخص الترجمة السحابية. العبارات المحلية وميزات Offline لا تحتاج حصة Online عندما تتوفر الحزمة المناسبة.',style:TextStyle(height:1.6,color:Colors.grey)),
    ]));
  }));
}
class _Quota extends StatelessWidget{final String title,reset;final int remaining,total;const _Quota({required this.title,required this.remaining,required this.total,required this.reset});@override Widget build(BuildContext context){final used=total<=0?0.0:((total-remaining)/total).clamp(0,1).toDouble();return Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),const Spacer(),Text('$remaining / $total متبقي')]),const SizedBox(height:12),LinearProgressIndicator(value:used,minHeight:8,borderRadius:BorderRadius.circular(20)),const SizedBox(height:8),Text(reset,style:const TextStyle(fontSize:12,color:Colors.grey))])));}}
