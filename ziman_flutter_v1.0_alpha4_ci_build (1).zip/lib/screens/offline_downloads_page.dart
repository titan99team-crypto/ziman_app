import 'package:flutter/material.dart';
import '../services/ocr_service.dart';

class OfflineDownloadsPage extends StatefulWidget { const OfflineDownloadsPage({super.key}); @override State<OfflineDownloadsPage> createState()=>_OfflineDownloadsPageState(); }
class _OfflineDownloadsPageState extends State<OfflineDownloadsPage>{
  final packs=OcrLanguagePackService(); List<OcrPackState>? states; final Map<String,double> progress={}; String? message;
  @override void initState(){super.initState(); refresh();}
  Future<void> refresh() async{ final s=await packs.states(); if(mounted)setState(()=>states=s); }
  Future<void> download(String code) async{setState(()=>progress[code]=0);try{await packs.download(code,onProgress:(r,t){if(mounted)setState(()=>progress[code]=t==null?0:(r/t).clamp(0,1).toDouble());});setState(()=>message='تم تنزيل الحزمة بنجاح.');await refresh();}catch(e){if(mounted)setState(()=>message=e.toString());}finally{if(mounted)setState(()=>progress.remove(code));}}
  Future<void> remove(String code) async{await packs.remove(code);await refresh();}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('العمل بدون إنترنت',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:8),
    const Text('نزّل ما تحتاجه فقط. حزم OCR أدناه حقيقية وتعمل محلياً بعد التنزيل. نموذج الترجمة العصبي Offline سيظهر هنا عندما يصبح ملف النموذج النهائي جاهزاً للنشر.',style:TextStyle(height:1.6,color:Colors.grey)),
    const SizedBox(height:18),
    const Text('حزم قراءة النص من الصور',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    if(states==null) const Center(child:Padding(padding:EdgeInsets.all(24),child:CircularProgressIndicator())) else ...states!.map((s)=>Card(child:ListTile(
      leading:Icon(s.installed?Icons.offline_pin_rounded:Icons.download_for_offline_outlined,color:s.installed?Colors.green:null),
      title:Text(s.label,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:progress[s.code]!=null?LinearProgressIndicator(value:progress[s.code]):Text(s.installed?'مثبت — يعمل بدون إنترنت':'غير مثبت'),
      trailing:s.installed?IconButton(onPressed:()=>remove(s.code),icon:const Icon(Icons.delete_outline),tooltip:'حذف الحزمة'):FilledButton.tonal(onPressed:progress.containsKey(s.code)?null:()=>download(s.code),child:const Text('تنزيل')),
    ))),
    const SizedBox(height:20),
    const Text('حزم الترجمة Offline',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    ...['العراقي ↔ السوراني','العراقي ↔ الكرمانجي','السوراني ↔ الكرمانجي'].map((e)=>Card(child:ListTile(leading:const Icon(Icons.model_training_rounded),title:Text(e),subtitle:const Text('سيُفعّل بعد ضغط واختبار النموذج على أجهزة Android حقيقية'),trailing:const Chip(label:Text('قريباً'))))),
    if(message!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(message!,textAlign:TextAlign.center)),
    const SizedBox(height:12),
    const Text('ملاحظة: تنزيل حزمة OCR يحتاج إنترنت مرة واحدة. بعد اكتمال التنزيل تبقى الحزمة على الجهاز حتى تحذفها.',style:TextStyle(fontSize:12,height:1.6,color:Colors.grey)),
  ]);
}
