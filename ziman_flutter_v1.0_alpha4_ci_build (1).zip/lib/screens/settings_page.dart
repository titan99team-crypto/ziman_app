import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../services/app_theme_controller.dart';
import '../services/app_preferences_service.dart';
import 'legal_page.dart';
import 'onboarding_page.dart';
import 'usage_page.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}
class _SettingsPageState extends State<SettingsPage> {
  final prefs = AppPreferencesService();
  ThemeMode theme = ThemeMode.system;
  bool analytics = false;
  bool notifications = false;
  String version = '…';
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final t = await prefs.themeMode();
    final a = await prefs.analyticsOptIn();
    final n = await prefs.notificationsOptIn();
    final info = await PackageInfo.fromPlatform();
    if (mounted) setState(() { theme=t; analytics=a; notifications=n; version='${info.version} (${info.buildNumber})'; });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإعدادات')),
    body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 28), children: [
      const _Section('المظهر'),
      Card(child: Column(children: [
        RadioListTile<ThemeMode>(value: ThemeMode.system, groupValue: theme, title: const Text('حسب الجهاز'), onChanged: _theme),
        RadioListTile<ThemeMode>(value: ThemeMode.light, groupValue: theme, title: const Text('فاتح'), onChanged: _theme),
        RadioListTile<ThemeMode>(value: ThemeMode.dark, groupValue: theme, title: const Text('داكن'), onChanged: _theme),
      ])),
      const _Section('الخصوصية والمزايا الاختيارية'),
      Card(child: Column(children: [
        SwitchListTile(value: analytics, title: const Text('مشاركة تحليلات الاستخدام'), subtitle: const Text('غير مربوط بأي SDK تحليلات حالياً. يبقى محلياً حتى نضيف خدمة بعد الموافقة.'), onChanged: (v) async { await prefs.setAnalyticsOptIn(v); setState(()=>analytics=v); }),
        const Divider(height: 1),
        SwitchListTile(value: notifications, title: const Text('إشعارات التعلم'), subtitle: const Text('تفضيل جاهز للمستقبل؛ لا توجد إشعارات Push مفعلة في v0.9.'), onChanged: (v) async { await prefs.setNotificationsOptIn(v); setState(()=>notifications=v); }),
      ])),
      const _Section('الحساب والاستخدام'),
      Card(child: Column(children: [
        ListTile(leading: const Icon(Icons.speed_rounded), title: const Text('حدود الترجمة'), subtitle: const Text('اعرض المتبقي لليوم والدقيقة'), trailing: const Icon(Icons.chevron_left), onTap: ()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>const UsagePage()))),
      ])),
      const _Section('قانوني'),
      Card(child: Column(children: [
        ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('سياسة الخصوصية'), trailing: const Icon(Icons.chevron_left), onTap: ()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>const LegalPage.privacy()))),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.gavel_outlined), title: const Text('شروط الاستخدام'), trailing: const Icon(Icons.chevron_left), onTap: ()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>const LegalPage.terms()))),
      ])),
      const _Section('حول التطبيق'),
      Card(child: Column(children: [
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('Ziman'), subtitle: Text('الإصدار $version')),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.slideshow_rounded), title: const Text('عرض شاشة البداية مرة أخرى'), onTap: () async { await prefs.resetOnboarding(); if (!context.mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder:(_)=>const OnboardingPage()), (_)=>false); }),
      ])),
    ]),
  );
  Future<void> _theme(ThemeMode? v) async {
    if (v == null) return;
    await prefs.setThemeMode(v);
    setState(()=>theme=v);
    AppThemeController.themeMode.value=v;
  }
}
class _Section extends StatelessWidget { final String text; const _Section(this.text); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(6,22,6,8),child:Text(text,style:TextStyle(fontWeight:FontWeight.w800,color:Theme.of(context).colorScheme.primary))); }
