import 'package:flutter/material.dart';

import '../data/course_data.dart';
import '../models/course_models.dart';
import '../services/course_progress_service.dart';
import '../services/purchase_service.dart';
import '../services/voice_service.dart';

class LearnPage extends StatefulWidget {
  const LearnPage({super.key});

  @override
  State<LearnPage> createState() => _LearnPageState();
}

class _LearnPageState extends State<LearnPage> {
  final _progress = CourseProgressService();
  final _purchase = PurchaseService();
  final _tts = TextToSpeechService();
  Set<String> _completed = {};
  bool _loadingProgress = true;

  @override
  void initState() {
    super.initState();
    _load();
    _purchase.addListener(_purchaseChanged);
    _purchase.initialize();
  }

  Future<void> _load() async {
    final completed = await _progress.completedLessonIds();
    if (!mounted) return;
    setState(() {
      _completed = completed;
      _loadingProgress = false;
    });
  }

  void _purchaseChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _purchase.removeListener(_purchaseChanged);
    _purchase.dispose();
    _tts.stop();
    super.dispose();
  }

  bool _isAccessible(CourseLesson lesson) => lesson.free || _purchase.purchased;

  Future<void> _openLesson(CourseLesson lesson) async {
    if (!_isAccessible(lesson)) {
      await _showPaywall();
      return;
    }
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => LessonPage(
        lesson: lesson,
        progress: _progress,
        tts: _tts,
      ),
    ));
    await _load();
  }

  Future<void> _showPaywall() => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 6, 20, 24),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                CircleAvatar(child: Icon(Icons.workspace_premium_rounded)),
                SizedBox(width: 12),
                Expanded(child: Text('افتح كورس Ziman الكامل', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
              ]),
              const SizedBox(height: 14),
              const Text('دفع مرة واحدة لفتح جميع المستويات والدروس الحالية والمحتوى الذي يضاف لهذا الكورس.', style: TextStyle(height: 1.6)),
              const SizedBox(height: 12),
              const _Benefit(icon: Icons.record_voice_over_rounded, text: 'جمل ومحادثات عامية بصياغة يومية'),
              const _Benefit(icon: Icons.quiz_outlined, text: 'اختبارات وتتبع تقدم لكل درس'),
              const _Benefit(icon: Icons.volume_up_rounded, text: 'تشغيل النطق عندما يتوفر صوت اللغة على الجهاز'),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _purchase.loading ? null : () async {
                    Navigator.pop(context);
                    await _purchase.buyCourse();
                  },
                  icon: const Icon(Icons.lock_open_rounded),
                  label: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    child: Text('فتح الكورس — ${_purchase.displayPrice}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
              TextButton.icon(onPressed: () async { Navigator.pop(context); await _purchase.restore(); }, icon: const Icon(Icons.restore_rounded), label: const Text('استعادة شراء سابق')),
              if (_purchase.message != null) Text(_purchase.message!, style: TextStyle(color: Theme.of(context).colorScheme.error, height: 1.4)),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final total = allCourseLessons.length;
    final done = _completed.intersection(allCourseLessons.map((e) => e.id).toSet()).length;
    final ratio = total == 0 ? 0.0 : done / total;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Row(children: [
          const CircleAvatar(radius: 24, child: Icon(Icons.school_rounded)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('تعلم الكردي العامي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            Text('مواقف حقيقية بدل الجمل الفصحى التقليدية.', style: TextStyle(color: Colors.grey)),
          ])),
          if (_purchase.purchased) const Chip(avatar: Icon(Icons.verified_rounded, size: 17), label: Text('مفتوح')),
        ]),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Theme.of(context).colorScheme.primaryContainer, Theme.of(context).colorScheme.secondaryContainer]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.workspace_premium_rounded, size: 38),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('كورس Ziman الكامل', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                Text(_purchase.purchased ? 'تم فتح جميع الدروس.' : 'دفع مرة واحدة • السعر يظهر من Google Play', style: const TextStyle(height: 1.4)),
              ])),
              if (!_purchase.purchased) Text(_purchase.displayPrice, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            ]),
            const SizedBox(height: 16),
            LinearProgressIndicator(value: _loadingProgress ? null : ratio, minHeight: 8, borderRadius: BorderRadius.circular(20)),
            const SizedBox(height: 8),
            Text('$done من $total درس مكتمل', style: const TextStyle(fontWeight: FontWeight.w700)),
            if (!_purchase.purchased) ...[
              const SizedBox(height: 14),
              FilledButton.tonal(onPressed: _showPaywall, child: const Text('شوف تفاصيل الكورس')),
            ],
          ]),
        ),
        if (_purchase.message != null) ...[
          const SizedBox(height: 10),
          Text(_purchase.message!, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 12)),
        ],
        const SizedBox(height: 22),
        ...courseLevels.map((level) => _LevelSection(
              level: level,
              completed: _completed,
              unlocked: _purchase.purchased,
              onLesson: _openLesson,
            )),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(16)),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.fact_check_outlined),
            SizedBox(width: 10),
            Expanded(child: Text('المحتوى الكردي الحالي Seed Curriculum تقني. قبل الإطلاق التجاري يجب مراجعته وتسجيله من متحدثين أصليين بالسوراني والكرمانجي.', style: TextStyle(height: 1.5))),
          ]),
        ),
      ],
    );
  }
}

class _LevelSection extends StatelessWidget {
  final CourseLevel level;
  final Set<String> completed;
  final bool unlocked;
  final ValueChanged<CourseLesson> onLesson;

  const _LevelSection({required this.level, required this.completed, required this.unlocked, required this.onLesson});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(level.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(level.description, style: const TextStyle(color: Colors.grey, height: 1.4)),
          const SizedBox(height: 10),
          ...level.lessons.map((lesson) {
            final accessible = lesson.free || unlocked;
            final isDone = completed.contains(lesson.id);
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  onTap: () => onLesson(lesson),
                  leading: CircleAvatar(
                    child: Icon(isDone ? Icons.check_rounded : accessible ? Icons.play_arrow_rounded : Icons.lock_outline_rounded),
                  ),
                  title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${lesson.subtitle}\n${lesson.minutes} دقيقة • ${lesson.situation}', maxLines: 3),
                  isThreeLine: true,
                  trailing: lesson.free && !unlocked ? const Chip(label: Text('مجاني')) : const Icon(Icons.chevron_left_rounded),
                ),
              ),
            );
          }),
        ]),
      );
}

class LessonPage extends StatefulWidget {
  final CourseLesson lesson;
  final CourseProgressService progress;
  final TextToSpeechService tts;

  const LessonPage({super.key, required this.lesson, required this.progress, required this.tts});

  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  int _tab = 0;
  String _target = 'sorani';
  final Map<int, int> _answers = {};
  bool _submitted = false;

  String _targetText(CoursePhrase phrase) => _target == 'sorani' ? phrase.sorani : phrase.kurmanji;
  String _dialogueTarget(DialogueLine line) => _target == 'sorani' ? line.sorani : line.kurmanji;

  Future<void> _speak(String text) async {
    final result = await widget.tts.speak(text: text, languageCode: _target);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message), duration: const Duration(seconds: 2)));
  }

  Future<void> _submitQuiz() async {
    if (widget.lesson.quiz.isEmpty) {
      await widget.progress.markCompleted(widget.lesson.id, score: 100);
      if (mounted) setState(() => _submitted = true);
      return;
    }
    var right = 0;
    for (var i = 0; i < widget.lesson.quiz.length; i++) {
      if (_answers[i] == widget.lesson.quiz[i].correctIndex) right++;
    }
    final score = ((right / widget.lesson.quiz.length) * 100).round();
    await widget.progress.markCompleted(widget.lesson.id, score: score);
    if (!mounted) return;
    setState(() => _submitted = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.lesson.title)),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Row(children: [
              Expanded(child: SegmentedButton<String>(
                segments: const [ButtonSegment(value: 'sorani', label: Text('سۆرانی')), ButtonSegment(value: 'kurmanji', label: Text('Kurmancî'))],
                selected: {_target},
                onSelectionChanged: (value) => setState(() => _target = value.first),
              )),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, icon: Icon(Icons.menu_book_rounded), label: Text('جمل')),
                ButtonSegment(value: 1, icon: Icon(Icons.forum_rounded), label: Text('محادثة')),
                ButtonSegment(value: 2, icon: Icon(Icons.quiz_rounded), label: Text('اختبار')),
              ],
              selected: {_tab},
              onSelectionChanged: (value) => setState(() => _tab = value.first),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(child: _tab == 0 ? _phrases() : _tab == 1 ? _dialogue() : _quiz()),
        ]),
      ),
    );
  }

  Widget _phrases() => ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: widget.lesson.phrases.length,
        itemBuilder: (context, index) {
          final p = widget.lesson.phrases[index];
          final target = _targetText(p);
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.iraqi, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Row(children: [Expanded(child: SelectableText(target, style: const TextStyle(fontSize: 19, height: 1.5))), IconButton(onPressed: () => _speak(target), icon: const Icon(Icons.volume_up_rounded))]),
                  if (p.note.isNotEmpty) Text(p.note, style: const TextStyle(color: Colors.grey)),
                ]),
              ),
            ),
          );
        },
      );

  Widget _dialogue() {
    if (widget.lesson.dialogue.isEmpty) {
      return const Center(child: Padding(padding: EdgeInsets.all(28), child: Text('سيُضاف حوار كامل لهذا الدرس ضمن تحرير المحتوى النهائي.', textAlign: TextAlign.center)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: widget.lesson.dialogue.length,
      itemBuilder: (context, index) {
        final line = widget.lesson.dialogue[index];
        final target = _dialogueTarget(line);
        return Align(
          alignment: index.isEven ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 360),
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(18)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('المتحدث ${line.speaker}', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
              Text(line.iraqi, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Row(children: [Expanded(child: Text(target, style: const TextStyle(fontSize: 17))), IconButton(onPressed: () => _speak(target), icon: const Icon(Icons.volume_up_rounded))]),
            ]),
          ),
        );
      },
    );
  }

  Widget _quiz() {
    if (widget.lesson.quiz.isEmpty) {
      return Center(child: FilledButton.icon(onPressed: _submitted ? null : _submitQuiz, icon: const Icon(Icons.check_rounded), label: Text(_submitted ? 'تم إكمال الدرس' : 'اعتبر الدرس مكتملاً')));
    }
    var correct = 0;
    if (_submitted) {
      for (var i = 0; i < widget.lesson.quiz.length; i++) {
        if (_answers[i] == widget.lesson.quiz[i].correctIndex) correct++;
      }
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ...List.generate(widget.lesson.quiz.length, (i) {
          final q = widget.lesson.quiz[i];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${i + 1}. ${q.prompt}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 8),
                ...List.generate(q.options.length, (optionIndex) => RadioListTile<int>(
                      value: optionIndex,
                      groupValue: _answers[i],
                      onChanged: _submitted ? null : (v) => setState(() => _answers[i] = v!),
                      title: Text(q.options[optionIndex]),
                    )),
                if (_submitted) Text(_answers[i] == q.correctIndex ? '✓ صحيح' : 'الإجابة الصحيحة: ${q.options[q.correctIndex]}', style: TextStyle(color: _answers[i] == q.correctIndex ? Colors.green : Theme.of(context).colorScheme.error, fontWeight: FontWeight.w800)),
              ]),
            ),
          );
        }),
        FilledButton(onPressed: _submitted ? null : _submitQuiz, child: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('إنهاء الاختبار'))),
        if (_submitted) Padding(padding: const EdgeInsets.all(16), child: Text('نتيجتك: $correct / ${widget.lesson.quiz.length}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
      ],
    );
  }
}

class _Benefit extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Benefit({required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [Icon(icon, size: 19), const SizedBox(width: 9), Expanded(child: Text(text))]),
      );
}
