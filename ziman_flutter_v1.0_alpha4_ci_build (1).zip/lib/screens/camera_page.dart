import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../models/language_option.dart';
import '../models/ocr_result.dart';
import '../models/translation_result.dart';
import '../services/ocr_service.dart';
import '../services/translation_service.dart';

class CameraPage extends StatefulWidget {
  final TranslationService translationService;
  const CameraPage({super.key, required this.translationService});

  @override
  State<CameraPage> createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  final _picker = ImagePicker();
  final _ocr = TesseractOcrService();
  final _packs = OcrLanguagePackService();
  XFile? _image;
  OcrResult? _ocrResult;
  TranslationResult? _translation;
  String _from = 'iraqi';
  String _to = 'sorani';
  bool _busy = false;
  String? _message;
  List<OcrPackState> _packStates = const [];
  final Map<String, double> _progress = {};

  @override
  void initState() {
    super.initState();
    _refreshPacks();
  }

  Future<void> _refreshPacks() async {
    try {
      final states = await _packs.states();
      if (mounted) setState(() => _packStates = states);
    } catch (_) {}
  }

  Future<void> _pick(ImageSource source) async {
    final image = await _picker.pickImage(
      source: source,
      imageQuality: 94,
      maxWidth: 2400,
    );
    if (image == null || !mounted) return;
    setState(() {
      _image = image;
      _ocrResult = null;
      _translation = null;
      _message = 'تم اختيار الصورة. اضغط «استخراج وترجمة». ';
    });
  }

  Future<void> _extractAndTranslate() async {
    if (_image == null) return;
    setState(() {
      _busy = true;
      _message = 'جاري قراءة النص من الصورة…';
      _ocrResult = null;
      _translation = null;
    });

    try {
      final ocr = await _ocr.extractText(
        imagePath: _image!.path,
        languageCode: _from,
      );
      TranslationResult? translated;
      if (!ocr.isEmpty) {
        translated = await widget.translationService.translate(
          text: ocr.text,
          from: _from,
          to: _to,
        );
      }
      if (!mounted) return;
      setState(() {
        _ocrResult = ocr;
        _translation = translated;
        _message = ocr.isEmpty
            ? 'لم يتم العثور على نص واضح. جرّب صورة أقرب أو إضاءة أفضل.'
            : 'تم استخراج النص محلياً.';
      });
    } on OcrException catch (e) {
      if (!mounted) return;
      setState(() => _message = e.message);
    } catch (e) {
      if (!mounted) return;
      setState(() => _message = 'حدث خطأ أثناء معالجة الصورة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _downloadPack(String code) async {
    setState(() {
      _progress[code] = 0;
      _message = 'جاري تنزيل حزمة ${OcrLanguagePackService.packLabels[code]}…';
    });
    try {
      await _packs.download(code, onProgress: (received, total) {
        if (!mounted) return;
        setState(() {
          if (total != null && total > 0) _progress[code] = received / total;
        });
      });
      await _refreshPacks();
      if (!mounted) return;
      setState(() => _message = 'تم تثبيت الحزمة. أصبحت قراءة هذه اللغة تعمل بدون إنترنت.');
    } on OcrException catch (e) {
      if (!mounted) return;
      setState(() => _message = e.message);
    } finally {
      if (mounted) setState(() => _progress.remove(code));
    }
  }

  void _swap() {
    setState(() {
      final t = _from;
      _from = _to;
      _to = t;
      _ocrResult = null;
      _translation = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(children: [
          const CircleAvatar(radius: 24, child: Icon(Icons.document_scanner_rounded)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('ترجمة من صورة', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            Text('صوّر النص، استخرجه محلياً، ثم ترجمه باللهجة المطلوبة.', style: TextStyle(color: Colors.grey, height: 1.5)),
          ])),
        ]),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: _LangDrop(value: _from, onChanged: (v) => setState(() => _from = v))),
              IconButton(onPressed: _swap, icon: const Icon(Icons.swap_horiz_rounded)),
              Expanded(child: _LangDrop(value: _to, onChanged: (v) => setState(() => _to = v))),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          height: 260,
          width: double.infinity,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(24),
          ),
          child: _image == null
              ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.camera_alt_outlined, size: 66),
                  SizedBox(height: 12),
                  Text('التقط صورة أو اخترها من الجهاز', style: TextStyle(fontWeight: FontWeight.w700)),
                ])
              : Image.file(File(_image!.path), fit: BoxFit.contain),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_rounded), label: const Text('التقط صورة'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('من المعرض'))),
        ]),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: _image == null || _busy ? null : _extractAndTranslate,
          icon: _busy
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.auto_awesome_rounded),
          label: Text(_busy ? 'جاري المعالجة…' : 'استخراج وترجمة'),
        ),
        if (_message != null) ...[
          const SizedBox(height: 12),
          _Info(text: _message!),
        ],
        const SizedBox(height: 20),
        _PackSection(states: _packStates, progress: _progress, onDownload: _downloadPack),
        if (_ocrResult != null && !_ocrResult!.isEmpty) ...[
          const SizedBox(height: 20),
          _TextResultCard(
            title: 'النص المستخرج',
            text: _ocrResult!.text,
            subtitle: '${_ocrResult!.engine} • ${_ocrResult!.language} • Offline',
          ),
        ],
        if (_translation != null) ...[
          const SizedBox(height: 12),
          _TextResultCard(
            title: 'الترجمة',
            text: _translation!.primary,
            subtitle: _translation!.confidence > 0
                ? 'الثقة ${(100 * _translation!.confidence).round()}% • ${_translation!.source}'
                : 'تحتاج محرك الترجمة الذكي أو مراجعة بشرية',
          ),
        ],
        const SizedBox(height: 18),
        const _Info(text: 'نصيحة OCR: قرّب الكاميرا من النص، تجنب الانعكاس، حافظ على استقامة الورقة، ولا تخلط أكثر من لغة في صورة واحدة إذا أردت أفضل دقة.'),
      ],
    );
  }
}

class _LangDrop extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  const _LangDrop({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => DropdownButtonFormField<String>(
        initialValue: value,
        decoration: const InputDecoration(border: OutlineInputBorder(), isDense: true),
        items: supportedLanguages
            .map((e) => DropdownMenuItem(value: e.code, child: Text('${e.flag} ${e.label}')))
            .toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      );
}

class _PackSection extends StatelessWidget {
  final List<OcrPackState> states;
  final Map<String, double> progress;
  final Future<void> Function(String code) onDownload;
  const _PackSection({required this.states, required this.progress, required this.onDownload});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('حزم قراءة الصور Offline', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('نزّل الحزمة مرة واحدة فقط، وبعدها OCR يعمل بدون إنترنت.', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 10),
          if (states.isEmpty)
            const LinearProgressIndicator()
          else
            ...states.map((s) {
              final downloading = progress.containsKey(s.code);
              final p = progress[s.code];
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(s.installed ? Icons.offline_pin_rounded : Icons.download_for_offline_outlined),
                title: Text(s.label, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: downloading
                    ? LinearProgressIndicator(value: (p != null && p > 0) ? p : null)
                    : Text(s.installed ? 'مثبتة على الجهاز' : 'غير مثبتة'),
                trailing: s.installed
                    ? const Icon(Icons.check_circle_rounded)
                    : TextButton(onPressed: downloading ? null : () => onDownload(s.code), child: const Text('تنزيل')),
              );
            }),
        ]),
      ),
    );
  }
}

class _TextResultCard extends StatelessWidget {
  final String title;
  final String text;
  final String subtitle;
  const _TextResultCard({required this.title, required this.text, required this.subtitle});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
              IconButton(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: text));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النص.')));
                  }
                },
                icon: const Icon(Icons.copy_rounded),
              ),
            ]),
            SelectableText(text, style: const TextStyle(fontSize: 17, height: 1.7)),
            const SizedBox(height: 8),
            Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ]),
        ),
      );
}

class _Info extends StatelessWidget {
  final String text;
  const _Info({required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(16)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.info_outline_rounded),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(height: 1.5))),
        ]),
      );
}
