import 'package:flutter/material.dart';

class LegalPage extends StatelessWidget {
  final bool privacy;
  const LegalPage.privacy({super.key}) : privacy = true;
  const LegalPage.terms({super.key}) : privacy = false;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(privacy ? 'سياسة الخصوصية — مسودة' : 'شروط الاستخدام — مسودة')),
    body: ListView(padding: const EdgeInsets.all(20), children: privacy ? _privacy(context) : _terms(context)),
  );

  List<Widget> _privacy(BuildContext context) => [
    _notice(context, 'هذه مسودة داخلية قبل الإطلاق. يجب مراجعتها قانونياً وتحديثها بعنوان الشركة والبريد وسياسات مزودي الخدمات قبل النشر.'),
    const _H('ما الذي يعالجه Ziman؟'),
    const _P('قد يرسل التطبيق النص المطلوب ترجمته إلى خادم Ziman عندما تستخدم الترجمة Online. الصوت يُحوّل إلى نص عبر إمكانات الجهاز/المزود المتاح، والصور تُعالج محلياً عند استخدام OCR المحلي. لا يُقصد حفظ نصوص الترجمة أو الصور أو التسجيلات في سجل الاستخدام الافتراضي.'),
    const _H('الحساب والمزامنة'),
    const _P('عند تسجيل الدخول، نخزن بيانات الحساب اللازمة، تقدم التعلم، تفضيلات اللغة واستحقاق الكورس. المصادقة والمزامنة تعتمد على Firebase عند تفعيلها.'),
    const _H('القياسات والتحليلات'),
    const _P('التحليلات التسويقية غير مفعلة في هذه النسخة. خيار المشاركة في التحليلات موجود كإعداد محلي، وأي SDK تحليلات يجب ألا يُفعل قبل تحديث هذه السياسة وربط الموافقة به.'),
    const _H('سجل الاستخدام التشغيلي'),
    const _P('قد يسجل الخادم بيانات تشغيلية محدودة مثل زوج اللغات، طول النص، نجاح الطلب ومصدر الترجمة لحماية الخدمة وقياس الجودة. لا يسجل النص الأصلي أو الترجمة في هذا السجل افتراضياً.'),
    const _H('الحذف والدعم'),
    const _P('قبل الإطلاق يجب توفير وسيلة واضحة لطلب حذف الحساب والبيانات، وبريد دعم صالح، وصفحة سياسة منشورة على الويب.'),
  ];

  List<Widget> _terms(BuildContext context) => [
    _notice(context, 'هذه شروط أولية وليست بديلاً عن مراجعة قانونية قبل نشر التطبيق تجارياً.'),
    const _H('الترجمة'),
    const _P('Ziman يساعد على الترجمة والتعلم، لكن لا يضمن خلو كل ترجمة من الخطأ. يجب عدم الاعتماد على التطبيق وحده في العقود، الإجراءات القانونية، الحالات الطبية أو أي موقف عالي المخاطر.'),
    const _H('الكورس المدفوع'),
    const _P('الكورس الكامل مخطط كشراء رقمي لمرة واحدة عبر متجر المنصة. السعر النهائي وسياسة الاسترداد تظهران من المتجر وتخضعان لشروطه.'),
    const _H('الاستخدام المقبول'),
    const _P('يُمنع إساءة استخدام الخدمة، محاولة تجاوز حدود الاستخدام، استخراج مفاتيح الخدمة، إعادة بيع الخدمة بطريقة غير مصرح بها، أو استخدام النظام لتعطيل الآخرين.'),
    const _H('التغييرات'),
    const _P('قد تتغير الميزات والنماذج وحدود الاستخدام مع تطوير المنتج، ويجب تحديث النسخة المنشورة من هذه الشروط عند حدوث تغييرات جوهرية.'),
  ];

  Widget _notice(BuildContext context, String text) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(context).colorScheme.tertiaryContainer, borderRadius: BorderRadius.circular(14)), child: Text(text, style: const TextStyle(height: 1.6)));
}
class _H extends StatelessWidget { final String text; const _H(this.text); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(top: 24, bottom: 8), child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))); }
class _P extends StatelessWidget { final String text; const _P(this.text); @override Widget build(BuildContext context) => Text(text, style: const TextStyle(height: 1.7)); }
