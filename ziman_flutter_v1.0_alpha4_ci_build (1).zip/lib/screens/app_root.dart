import 'package:flutter/material.dart';
import '../services/app_preferences_service.dart';
import 'home_screen.dart';
import 'onboarding_page.dart';

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});
  @override
  State<AppRoot> createState() => _AppRootState();
}
class _AppRootState extends State<AppRoot> {
  bool? complete;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final value = await AppPreferencesService().onboardingComplete();
    if (mounted) setState(() => complete = value);
  }
  @override
  Widget build(BuildContext context) {
    if (complete == null) return const _Splash();
    return complete! ? const HomeScreen() : const OnboardingPage();
  }
}
class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 86, height: 86, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(26)), child: const Icon(Icons.language_rounded, size: 46, color: Colors.white)),
    const SizedBox(height: 18),
    const Text('Ziman', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    const Text('احچيها بطبيعتك'),
    const SizedBox(height: 26),
    const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.4)),
  ])));
}
