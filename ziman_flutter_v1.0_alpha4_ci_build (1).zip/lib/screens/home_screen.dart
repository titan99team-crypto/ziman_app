import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/language_option.dart';
import '../models/translation_result.dart';
import '../services/translation_service.dart';
import '../services/voice_service.dart';
import 'camera_page.dart';
import 'learn_page.dart';
import 'profile_page.dart';
import 'offline_downloads_page.dart';
import 'settings_page.dart';
import '../services/connectivity_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  final _service = HybridTranslationService();
  final _voice = VoiceRecognitionService();
  final _tts = TextToSpeechService();

  @override
  void dispose() {
    _voice.cancel();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      TranslatorPage(service: _service, voice: _voice, tts: _tts),
      ConversationPage(service: _service, voice: _voice, tts: _tts),
      CameraPage(translationService: _service),
      const LearnPage(),
      const OfflineDownloadsPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: Column(children: [const _ConnectivityBanner(), Expanded(child: pages[_index])])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (v) => setState(() => _index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.translate_rounded), label: 'ترجمة'),
          NavigationDestination(icon: Icon(Icons.record_voice_over_rounded), label: 'محادثة'),
          NavigationDestination(icon: Icon(Icons.document_scanner_rounded), label: 'صورة'),
          NavigationDestination(icon: Icon(Icons.school_rounded), label: 'تعلم'),
          NavigationDestination(icon: Icon(Icons.download_for_offline_rounded), label: 'أوفلاين'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'حساب'),
        ],
      ),
    );
  }
}

class TranslatorPage extends StatefulWidget {
  final TranslationService service;
  final VoiceRecognitionService voice;
  final TextToSpeechService tts;

  const TranslatorPage({
    super.key,
    required this.service,
    required this.voice,
    required this.tts,
  });

  @override
  State<TranslatorPage> createState() => _TranslatorPageState();
}

class _TranslatorPageState extends State<TranslatorPage> {
  final controller = TextEditingController();
  String from = 'iraqi';
  String to = 'sorani';
  TranslationResult? result;
  bool busy = false;
  bool listening = false;
  String? voiceMessage;

  LanguageOption get toLang => supportedLanguages.firstWhere((e) => e.code == to);

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> runTranslate() async {
    if (controller.text.trim().isEmpty) return;
    setState(() => busy = true);
    final out = await widget.service.translate(text: controller.text, from: from, to: to);
    if (!mounted) return;
    setState(() {
      result = out;
      busy = false;
    });
  }

  Future<void> toggleListening() async {
    if (listening || widget.voice.isListening) {
      await widget.voice.stop();
      if (!mounted) return;
      setState(() {
        listening = false;
        voiceMessage = 'تم إيقاف الاستماع.';
      });
      if (controller.text.trim().isNotEmpty) await runTranslate();
      return;
    }

    setState(() {
      listening = true;
      voiceMessage = 'جاري تجهيز الميكروفون…';
    });

    final capability = await widget.voice.listen(
      languageCode: from,
      onResult: (r) {
        if (!mounted) return;
        setState(() {
          controller.text = r.text;
          controller.selection = TextSelection.collapsed(offset: controller.text.length);
          voiceMessage = r.isFinal ? 'تم التقاط الجملة.' : 'أستمع… ${r.text}';
          if (r.isFinal) listening = false;
        });
        if (r.isFinal && r.text.trim().isNotEmpty) runTranslate();
      },
      onStatus: (status) {
        if (!mounted) return;
        if (status == 'done' || status == 'notListening') {
          setState(() => listening = false);
        }
      },
      onError: (error) {
        if (!mounted) return;
        setState(() {
          listening = false;
          voiceMessage = 'خطأ بالصوت: $error';
        });
      },
    );

    if (!mounted) return;
    setState(() {
      voiceMessage = capability.message;
      if (!capability.available) listening = false;
    });
  }

  Future<void> speakResult() async {
    final text = result?.primary;
    if (text == null || result!.confidence <= 0) return;
    final capability = await widget.tts.speak(text: text, languageCode: to);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(capability.message)));
  }

  void swap() {
    setState(() {
      final temp = from;
      from = to;
      to = temp;
      final previous = result?.primary;
      if (previous != null && result!.confidence > 0) controller.text = previous;
      result = null;
      voiceMessage = null;
    });
  }

  void usePhrase(String phrase) {
    controller.text = phrase;
    runTranslate();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.language_rounded, color: Colors.white)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ziman', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), Text('ترجمة باللهجة… مو بالفصحى', style: TextStyle(color: Colors.grey))])),
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsPage())), icon: const Icon(Icons.settings_outlined), tooltip: 'الإعدادات'),
        ]),
        const SizedBox(height: 24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Expanded(child: _LanguageSelector(value: from, onChanged: (v) => setState(() => from = v))),
              IconButton.filledTonal(onPressed: swap, icon: const Icon(Icons.swap_horiz_rounded)),
              Expanded(child: _LanguageSelector(value: to, onChanged: (v) => setState(() => to = v))),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerLowest, borderRadius: BorderRadius.circular(22), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            TextField(
              controller: controller,
              minLines: 5,
              maxLines: 9,
              maxLength: 500,
              onChanged: (_) => setState(() {}),
              textInputAction: TextInputAction.newline,
              decoration: InputDecoration(border: InputBorder.none, counterText: '', hintText: 'اكتب أو احچي مثل ما تستخدمها يومياً…\nمثال: شلونك؟ وين رايح؟', hintStyle: TextStyle(color: Colors.grey.shade500)),
            ),
            Row(children: [
              IconButton.filled(
                onPressed: toggleListening,
                tooltip: listening ? 'إيقاف الاستماع' : 'تكلم الآن',
                icon: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded),
              ),
              if (listening) ...[
                const SizedBox(width: 8),
                const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
              ],
              const Spacer(),
              Text('${controller.text.length}/500', style: const TextStyle(color: Colors.grey)),
            ]),
            if (voiceMessage != null) ...[
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerRight, child: Text(voiceMessage!, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.primary))),
            ],
          ]),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: busy ? null : runTranslate,
          icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome_rounded),
          label: const Padding(padding: EdgeInsets.symmetric(vertical: 13), child: Text('ترجم باللهجة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        ),
        const SizedBox(height: 16),
        if (result != null) _TranslationCard(result: result!, language: toLang, onSpeak: speakResult),
        const SizedBox(height: 18),
        _PhraseSuggestions(onTap: usePhrase),
      ],
    );
  }
}

class _TranslationCard extends StatelessWidget {
  final TranslationResult result;
  final LanguageOption language;
  final VoidCallback onSpeak;
  const _TranslationCard({required this.result, required this.language, required this.onSpeak});

  @override
  Widget build(BuildContext context) {
    final confidencePct = (result.confidence * 100).round();
    return Card(
      color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .42),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('${language.flag} ${language.label}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const Spacer(),
            if (result.confidence > 0) Chip(label: Text('$confidencePct% ثقة')),
            IconButton(onPressed: result.confidence > 0 ? onSpeak : null, tooltip: 'استمع للترجمة', icon: const Icon(Icons.volume_up_rounded)),
            IconButton(onPressed: () => Clipboard.setData(ClipboardData(text: result.primary)), tooltip: 'نسخ', icon: const Icon(Icons.copy_rounded)),
          ]),
          const SizedBox(height: 8),
          SelectableText(result.primary, style: const TextStyle(fontSize: 21, height: 1.6, fontWeight: FontWeight.w700)),
          if (result.alternative != null) ...[
            const SizedBox(height: 14),
            Text('بديل شائع', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
            Text(result.alternative!, style: const TextStyle(fontSize: 17, height: 1.5)),
          ],
          if (result.literal != null) ...[
            const SizedBox(height: 10),
            Text('المعنى الحرفي: ${result.literal!}', style: const TextStyle(color: Colors.black54)),
          ],
          if (result.note != null) ...[
            const SizedBox(height: 12),
            const Divider(),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.tips_and_updates_outlined, size: 18),
              const SizedBox(width: 7),
              Expanded(child: Text(result.note!, style: const TextStyle(height: 1.5))),
            ]),
          ],
          if (result.needsReview) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.errorContainer.withValues(alpha: .45), borderRadius: BorderRadius.circular(12)),
              child: const Row(children: [Icon(Icons.fact_check_outlined, size: 18), SizedBox(width: 8), Expanded(child: Text('هذه النتيجة ضمن قاعدة أولية وتحتاج اعتماداً لغوياً بشرياً قبل الإطلاق العام.'))]),
            ),
          ],
          const SizedBox(height: 12),
          Row(children: [
            const Text('هل الترجمة طبيعية؟', style: TextStyle(fontWeight: FontWeight.w700)),
            const Spacer(),
            IconButton(onPressed: () {}, icon: const Icon(Icons.thumb_up_alt_outlined)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.thumb_down_alt_outlined)),
          ]),
        ]),
      ),
    );
  }
}

class _LanguageSelector extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  const _LanguageSelector({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: value,
          items: supportedLanguages.map((e) => DropdownMenuItem(value: e.code, child: Text('${e.flag}  ${e.label}', overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (v) { if (v != null) onChanged(v); },
        ),
      );
}

class _PhraseSuggestions extends StatelessWidget {
  final ValueChanged<String> onTap;
  const _PhraseSuggestions({required this.onTap});

  @override
  Widget build(BuildContext context) {
    const phrases = ['شلونك؟', 'وين رايح؟', 'هسه', 'باچر', 'ما أدري', 'شنو؟'];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('جرّب جمل عامية', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: phrases.map((e) => ActionChip(label: Text(e), onPressed: () => onTap(e))).toList()),
    ]);
  }
}

class ConversationPage extends StatefulWidget {
  final TranslationService service;
  final VoiceRecognitionService voice;
  final TextToSpeechService tts;

  const ConversationPage({super.key, required this.service, required this.voice, required this.tts});

  @override
  State<ConversationPage> createState() => _ConversationPageState();
}

class _ConversationPageState extends State<ConversationPage> {
  String first = 'iraqi';
  String second = 'sorani';
  String firstText = '';
  String secondText = '';
  String? activeSide;
  String status = 'اضغط الميكروفون عند الشخص الذي سيتكلم.';

  Future<void> listenFrom({required bool firstSide}) async {
    final from = firstSide ? first : second;
    final to = firstSide ? second : first;
    if (widget.voice.isListening) await widget.voice.cancel();

    setState(() {
      activeSide = firstSide ? 'first' : 'second';
      status = 'جاري تجهيز الميكروفون…';
    });

    final capability = await widget.voice.listen(
      languageCode: from,
      onResult: (r) async {
        if (!mounted) return;
        setState(() {
          if (firstSide) {
            firstText = r.text;
          } else {
            secondText = r.text;
          }
        });
        if (r.isFinal && r.text.trim().isNotEmpty) {
          final translated = await widget.service.translate(text: r.text, from: from, to: to);
          if (!mounted) return;
          setState(() {
            if (firstSide) {
              secondText = translated.primary;
            } else {
              firstText = translated.primary;
            }
            activeSide = null;
            status = translated.confidence > 0 ? 'تمت الترجمة. جاري محاولة قراءة النتيجة.' : 'لم نجد ترجمة موثوقة لهذه العبارة بعد.';
          });
          if (translated.confidence > 0) {
            final ttsResult = await widget.tts.speak(text: translated.primary, languageCode: to);
            if (!mounted) return;
            setState(() => status = ttsResult.message);
          }
        }
      },
      onStatus: (value) {
        if (!mounted) return;
        if (value == 'done' || value == 'notListening') setState(() => activeSide = null);
      },
      onError: (value) {
        if (!mounted) return;
        setState(() {
          activeSide = null;
          status = 'خطأ بالصوت: $value';
        });
      },
    );

    if (!mounted) return;
    setState(() {
      status = capability.message;
      if (!capability.available) activeSide = null;
    });
  }

  void swapLanguages() {
    setState(() {
      final temp = first;
      first = second;
      second = temp;
      final tempText = firstText;
      firstText = secondText;
      secondText = tempText;
    });
  }

  @override
  Widget build(BuildContext context) => _FeatureScaffold(
    icon: Icons.record_voice_over_rounded,
    title: 'محادثة مباشرة',
    subtitle: 'كل شخص يتكلم بلغته، والتطبيق يحاول ترجمة الجملة وقراءتها للطرف الثاني.',
    child: Column(children: [
      _ConversationPartyCard(
        title: 'الطرف الأول',
        language: first,
        text: firstText,
        listening: activeSide == 'first',
        onLanguage: (v) => setState(() => first = v),
        onMic: () => listenFrom(firstSide: true),
      ),
      const SizedBox(height: 8),
      IconButton.filledTonal(onPressed: swapLanguages, icon: const Icon(Icons.swap_vert_rounded)),
      const SizedBox(height: 8),
      _ConversationPartyCard(
        title: 'الطرف الثاني',
        language: second,
        text: secondText,
        listening: activeSide == 'second',
        onLanguage: (v) => setState(() => second = v),
        onMic: () => listenFrom(firstSide: false),
      ),
      const SizedBox(height: 18),
      _StatusCard(text: status),
      const SizedBox(height: 8),
      const _StatusCard(text: 'دقة Speech-to-Text والصوت الكردي تعتمد حالياً على اللغات المثبتة في الجهاز. النسخة الإنتاجية ستسمح باستبدال هذه الطبقة بخدمة صوت مخصصة بعد اختبار اللهجات.'),
    ]),
  );
}

class _ConversationPartyCard extends StatelessWidget {
  final String title;
  final String language;
  final String text;
  final bool listening;
  final ValueChanged<String> onLanguage;
  final VoidCallback onMic;

  const _ConversationPartyCard({
    required this.title,
    required this.language,
    required this.text,
    required this.listening,
    required this.onLanguage,
    required this.onMic,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const Spacer(),
            SizedBox(width: 165, child: _LanguageSelector(value: language, onChanged: onLanguage)),
          ]),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            constraints: const BoxConstraints(minHeight: 82),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(16)),
            child: Text(text.isEmpty ? 'سيظهر الكلام هنا…' : text, style: TextStyle(fontSize: 18, height: 1.5, color: text.isEmpty ? Colors.grey : null)),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: onMic,
              icon: Icon(listening ? Icons.graphic_eq_rounded : Icons.mic_rounded),
              label: Text(listening ? 'أستمع الآن…' : 'تكلم'),
            ),
          ),
        ]),
      ),
    );
  }
}

class _FeatureScaffold extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;
  const _FeatureScaffold({required this.icon, required this.title, required this.subtitle, required this.child});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Row(children: [CircleAvatar(radius: 24, child: Icon(icon)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(color: Colors.grey, height: 1.5))]))]),
    const SizedBox(height: 24), child,
  ]);
}

class _StatusCard extends StatelessWidget {
  final String text;
  const _StatusCard({required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainer, borderRadius: BorderRadius.circular(16)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.engineering_outlined), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(height: 1.5)))]));
}



class _ConnectivityBanner extends StatelessWidget {
  const _ConnectivityBanner();
  @override
  Widget build(BuildContext context) {
    final service = ConnectivityService();
    return StreamBuilder<ConnectivitySnapshot>(
      stream: service.changes,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return FutureBuilder<ConnectivitySnapshot>(
            future: service.current(),
            builder: (context, first) => _bar(context, first.data),
          );
        }
        return _bar(context, snapshot.data);
      },
    );
  }
  Widget _bar(BuildContext context, ConnectivitySnapshot? value) {
    if (value == null || value.hasNetworkInterface) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      color: Theme.of(context).colorScheme.errorContainer,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.cloud_off_rounded, size: 17, color: Theme.of(context).colorScheme.onErrorContainer),
        const SizedBox(width: 7),
        Text('لا توجد شبكة — سيستخدم Ziman ما هو متوفر محلياً', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onErrorContainer)),
      ]),
    );
  }
}
