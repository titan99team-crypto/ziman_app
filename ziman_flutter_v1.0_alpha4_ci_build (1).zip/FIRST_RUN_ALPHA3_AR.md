# Ziman v1.0 Alpha.3 — First Build

## ما تم إصلاحه في Alpha.3
- تثبيت حد أدنى Flutter 3.47.0 داخل pubspec.
- إضافة `android.builtInKotlin=false` و `android.newDsl=false` صراحةً لتوافق AGP 9 مع الإضافات الحالية إلى أن تتم هجرة جميع Plugins إلى Built-in Kotlin / New DSL.
- تشديد preflight حتى يفشل إذا غابت هذه الإعدادات.
- الإبقاء على Gradle 9.6.1 و AGP 9.4.0 و targetSdk 36.

## أول تشغيل على Windows
1. ثبّت Flutter 3.47 Stable وAndroid Studio/Android SDK.
2. افتح PowerShell داخل مجلد المشروع.
3. شغّل: `./tool/first_run.ps1`
4. أضف Firebase الحقيقي عند الحاجة إلى الحساب والمزامنة.
5. شغّل الـBackend، ثم: `flutter run --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080`
6. لإخراج APK Debug: `flutter build apk --debug --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080`

## ملاحظة
هذه الحزمة تم فحص بنيتها وملفات Android/Backend داخل بيئة لا تحتوي Flutter SDK أو Android SDK، لذلك لا يتم الادعاء بأن APK تم بناؤه هنا. أول `flutter analyze` و`flutter test` وGradle build على جهاز تطوير هما الاختبار النهائي.
