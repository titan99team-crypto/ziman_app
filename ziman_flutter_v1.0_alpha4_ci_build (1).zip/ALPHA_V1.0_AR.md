# Ziman v1.0 Alpha — جاهزية Android

هذه النسخة هي أول حزمة مشروع تحتوي على هيكل Android كامل داخل المشروع بدل الاعتماد على ملفات Dart فقط.

## ما تم تثبيته
- Application ID مؤقت: `com.titan.ziman` — غيّره قبل إنشاء التطبيق النهائي في Google Play إذا أردت معرفاً آخر.
- `compileSdk = 36` و `targetSdk = 36` لتلبية متطلب Google Play للتطبيقات الجديدة ابتداءً من 31 أغسطس 2026.
- `minSdk = 24` لأن عدداً من حزم Flutter الحديثة المستخدمة في Ziman يدعم Android API 24+.
- Java 17 / Kotlin JVM 17.
- صلاحيات الصوت والكاميرا والإنترنت وBluetooth اللازمة للتعرف الصوتي.
- `queries` لـ Android Speech Recognition وTTS.
- Cleartext HTTP ممنوع في Release، ومسموح فقط في Debug حتى يعمل `10.0.2.2` أثناء التطوير.
- تصغير الكود والموارد في Release مع ProGuard rules أولية.

## Firebase
1. أنشئ Android app في Firebase بنفس package name.
2. ضع الملف الحقيقي في `android/app/google-services.json`.
3. افتح `android/app/build.gradle.kts` وفك تعليق:
   `id("com.google.gms.google-services")`
4. نفّذ `flutterfire configure` عندما يتوفر FlutterFire CLI. يفضّل لاحقاً توليد `firebase_options.dart` واستخدامه بدلاً من الاعتماد على الإعداد التلقائي فقط.
5. أضف SHA-1 وSHA-256 لتسجيل Google/الهاتف.

## تشغيل Alpha محلياً
```bash
flutter doctor -v
flutter pub get
python tool/preflight.py
flutter analyze
flutter test
flutter run --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080
```

## بناء AAB تجريبي
قبل Release حقيقي، أنشئ upload keystore ولا تستخدم debug signing.
```bash
flutter build appbundle --release --dart-define=ZIMAN_API_BASE_URL=https://api.YOUR-DOMAIN.com
```

## ما لم يتم ادعاء اختباره في هذه الحزمة
هذه البيئة لا تحتوي Flutter SDK/Android SDK، لذلك لم يتم تنفيذ `flutter analyze`, `flutter test` أو Gradle build هنا. تم تنفيذ فحوص بنيوية وPython backend compilation فقط. أول Build حقيقي يجب أن يتم على جهاز تطوير يحتوي Flutter + Android SDK 36.

## Checklist قبل أول Closed Test
- [ ] تثبيت Flutter Stable وAndroid SDK 36.
- [ ] `flutter pub get` بدون تعارضات.
- [ ] `flutter analyze` = صفر Errors.
- [ ] `flutter test` ناجح.
- [ ] إضافة Firebase الحقيقي.
- [ ] تشغيل Backend على HTTPS.
- [ ] تغيير signing إلى Upload Key خاص بك.
- [ ] اختبار Google Sign-In وPhone OTP على جهاز حقيقي.
- [ ] اختبار microphone + TTS + OCR على جهاز عربي وكردي.
- [ ] إعداد المنتج `ziman_kurdish_course_full` في Play Console واختباره بحساب License Tester.
- [ ] مراجعة Privacy Policy / Data Safety / Account deletion.
- [ ] بناء AAB ورفعه إلى Internal أو Closed testing أولاً.
