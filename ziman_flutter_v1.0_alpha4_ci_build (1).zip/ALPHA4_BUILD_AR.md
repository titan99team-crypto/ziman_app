# Ziman v1.0 Alpha.4 — أول Build عبر GitHub Actions

هذه النسخة تضيف مسار Build حقيقي عبر GitHub Actions، بحيث لا تحتاج في البداية إلى تجهيز Android SDK على جهازك فقط لاستخراج APK تجريبي.

## ماذا يفعل الـ Workflow؟
1. يثبت Java 21.
2. يثبت Flutter 3.47.0 Stable.
3. ينشئ Gradle Wrapper من قالب Flutter الرسمي بواسطة `tool/bootstrap_android_wrapper.py`.
4. يشغل `tool/preflight.py`.
5. يشغل `flutter pub get`.
6. يشغل `flutter analyze`.
7. يشغل `flutter test`.
8. يبني `app-debug.apk`.
9. يرفع APK كـ Artifact باسم `ziman-alpha4-debug-apk` لمدة 14 يوماً.

## طريقة الاستخدام
- ارفع محتويات المشروع إلى GitHub repository خاص.
- افتح تبويب Actions.
- اختر `Android Alpha Build`.
- اضغط `Run workflow`.
- بعد نجاح الـ job، افتح قسم Artifacts وحمّل `ziman-alpha4-debug-apk`.

## ملاحظات مهمة
- APK الناتج Debug للاختبار فقط، وليس للنشر على Google Play.
- Firebase غير مفعّل في CI إلى أن تضيف إعدادك الحقيقي. التطبيق يبقى في Guest mode بدلاً من تضمين أسرار في المستودع.
- عنوان Backend في Build التجريبي موضوع على نطاق غير صالح عمداً. قبل اختبار الترجمة Online ضع عنوان HTTPS الحقيقي عبر `--dart-define=ZIMAN_API_BASE_URL=...` أو Secret/Variable في CI.
- لا تضع مفاتيح API أو Service Account JSON داخل GitHub repository.

## قبل Play Store
نحتاج لاحقاً إلى Upload Keystore، Firebase حقيقي، Backend HTTPS حقيقي، وسياسة خصوصية نهائية، ثم Build AAB Release موقّع.
