# Ziman v1.0 Alpha.2

> Android Alpha hardening package. ابدأ من `FIRST_RUN_ALPHA2_AR.md`.

> ملاحظة: Gradle wrapper binary لا يُشحن داخل الحزمة؛ يتم توليده من Flutter SDK المثبت لديك بواسطة `tool/bootstrap_android_wrapper.py` لضمان مصدر موثوق.

# Ziman — Iraqi / Sorani / Kurmanji colloquial translator

MVP source project for a mobile translation + language-learning application.

## Current stage
This package contains the first usable UI architecture and a tiny demo phrase dictionary. It deliberately does **not** pretend that production-grade translation, Kurdish TTS, OCR, or offline neural translation are already solved.

### Implemented in source
- Arabic RTL Material 3 mobile UI
- Iraqi / Sorani / Kurmanji selectors
- Text translation screen with demo colloquial phrases
- Conversation screen UI
- Camera/OCR screen UI
- Kurdish colloquial learning/course screen
- Offline language-pack screen
- Translation service abstraction so online/offline engines can be swapped later

### Production integrations still required
1. Colloquial translation backend/model + curated human phrase corpus
2. Speech-to-text per dialect
3. Kurdish + Iraqi voice/TTS quality evaluation and provider integration
4. OCR engine verified for Arabic-script Arabic/Sorani plus Latin Kurmanji
5. On-device compressed translation model and downloadable model packs
6. Authentication, payments, course entitlements, analytics, privacy/consent
7. Store signing/release setup

## Target toolchain
- Flutter 3.47 stable (September 2026 current stable line)
- Dart 3.12+

## Run locally
1. Install Flutter stable.
2. `flutter pub get`
3. `flutter run`

## Suggested architecture for production
- Flutter mobile client
- API gateway/backend (Supabase/Firebase or custom)
- Translation service interface with online + offline implementations
- Versioned local phrase/correction database
- Download manager for quantized offline models
- Human review/admin console for dialect corrections

## Product principle
Do not translate Iraqi colloquial Arabic into Modern Standard Arabic first. The translation system should preserve intent, register, social context and natural phrasing between Iraqi Arabic, Sorani and Kurmanji.


## ما أضيف في 0.3
- إدخال صوتي فعلي في صفحة الترجمة باستخدام `speech_to_text` 7.5.0.
- نطق الترجمة عبر `flutter_tts` 4.2.5 عند توفر صوت مناسب على الجهاز.
- اكتشاف Locales المتاحة وقت التشغيل بدل افتراض دعم السوراني/الكرمانجي على كل هاتف.
- وضع محادثة صوتية ثنائي الاتجاه مع ترجمة ونطق تلقائي.
- ملفات إعداد صلاحيات Android/iOS داخل `platform_setup/`.
- ملف `VOICE_ARCHITECTURE_AR.md` يشرح القيود وخطة الاختبار.

## ما أضيف في 0.2
- محرك HybridTranslationService بدل DemoTranslationService.
- قاعدة JSON محلية منظمة للهجات.
- Normalization للكتابة العربية الشائعة.
- TranslationResult يحتوي ترجمة أساسية، بديل، معنى حرفي، ملاحظة، درجة ثقة ومصدر.
- عدم تخمين ترجمة عند عدم وجود نتيجة موثوقة.
- واجهة Feedback مبدئية تمهيداً للمراجعة البشرية.
- ملف ARCHITECTURE_AR.md يشرح معمارية محرك الترجمة.

**مهم:** corpus الحالي Seed تجريبي ويحتاج اعتماد متحدثين أصليين قبل إطلاق الإنتاج.

## v0.4 Image OCR
تمت إضافة صفحة ترجمة الصور الفعلية: Camera/Gallery + Tesseract Offline + تنزيل حزم OCR + تمرير النص إلى محرك الترجمة. راجع `IMAGE_OCR_ARCHITECTURE_AR.md`.

> ملاحظة: ملفات traineddata لا تُضمّن داخل هذا zip لتجنب تضخيمه؛ التطبيق ينزلها عند الطلب من المصدر الرسمي عبر `OcrLanguagePackService`. قبل الإنتاج ننقلها إلى CDN خاص بـ Ziman مع checksum/versioning.


## v0.6 — Learning + Google Play Billing
- Course system with levels, lessons, colloquial phrases, dialogues and quizzes.
- Local learning progress with `shared_preferences`.
- One-time non-consumable course purchase using official Flutter `in_app_purchase`.
- Product ID: `ziman_kurdish_course_full`.
- Course entitlement is granted only after server-side Google Play verification.
- See `COURSE_AND_BILLING_ARCHITECTURE_AR.md`.

## v0.7 — الحساب والمزامنة
أضيف Firebase Auth (Google + Phone)، صفحة الملف الشخصي، بنية Firestore لمزامنة تقدم التعلم، وربط هوية Firebase مع طلب التحقق من شراء الكورس. راجع `FIREBASE_AUTH_SYNC_AR.md` قبل التشغيل الحقيقي.


## v0.9 — Backend Production Security
راجع `BACKEND_SECURITY_V0.9_AR.md`. أضيف تحقق Firebase ID Token، Redis rate limits، سجل استخدام بدون تخزين نصوص، وربط آمن لاستحقاق الكورس بحساب المستخدم.


## v0.9 UX
راجع `CHANGELOG_V0.9_AR.md` و`COMMERCIAL_READINESS_V0.9_AR.md`.
