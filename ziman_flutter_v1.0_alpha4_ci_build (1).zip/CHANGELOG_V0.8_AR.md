# Ziman v0.8

- تحقق Firebase ID Token على Backend.
- ترجمة مجانية بحدود منفصلة للضيف والمستخدم المسجل.
- Redis rate limiting مع fallback تطويري محلي.
- Usage logging يحترم الخصوصية ولا يخزن نص الترجمة.
- ربط Google Play Purchase Token بحساب Firebase واحد فقط.
- منح course_full من Firebase Admin فقط.
- تحديث Firestore Rules للاستحقاقات والسجلات الحساسة.
- إرسال ID Token تلقائياً من Flutter إلى محرك الترجمة.
- اشتراط تسجيل الدخول قبل شراء الكورس.
