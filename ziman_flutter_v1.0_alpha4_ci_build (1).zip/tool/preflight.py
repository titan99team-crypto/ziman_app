#!/usr/bin/env python3
from pathlib import Path
import sys, json, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors=[]; warnings=[]

def must(path, text=None, binary=False):
    p=root/path
    if not p.exists():
        errors.append(f'MISSING: {path}')
        return b'' if binary else ''
    if binary:
        return p.read_bytes()
    data=p.read_text(errors='ignore')
    if text and text not in data: errors.append(f'{path}: missing {text}')
    return data

pub=must(Path('pubspec.yaml'),'version: 1.0.0-alpha.4+13')
must(Path('android/app/src/main/AndroidManifest.xml'),'android.permission.RECORD_AUDIO')
must(Path('android/app/build.gradle.kts'),'targetSdk = 36')
settings=must(Path('android/settings.gradle.kts'),'com.android.application')
must(Path('android/gradle/wrapper/gradle-wrapper.properties'),'gradle-9.6.1-bin.zip')
gradle_props=must(Path('android/gradle.properties'),'android.builtInKotlin=false')
if 'android.newDsl=false' not in gradle_props: errors.append('android/gradle.properties: missing android.newDsl=false for AGP 9 compatibility')
if "flutter: '>=3.47.0'" not in pub: errors.append('pubspec.yaml: Flutter 3.47 minimum is not declared')
must(Path('lib/main.dart'),'runApp')
must(Path('backend/requirements.txt'))

# XML parse check.
for rel in [
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/debug/AndroidManifest.xml',
    'android/app/src/profile/AndroidManifest.xml',
]:
    p=root/rel
    if p.exists():
        try: ET.parse(p)
        except Exception as e: errors.append(f'{rel}: invalid XML: {e}')

# JSON checks for bundled non-secret config/data.
for p in root.glob('assets/**/*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{p.relative_to(root)}: invalid JSON: {e}')

# Wrapper binary is intentionally hydrated from local Flutter installation.
wrapper_jar=root/'android/gradle/wrapper/gradle-wrapper.jar'
if not wrapper_jar.exists():
    warnings.append('Gradle wrapper JAR not bundled. Run: python tool/bootstrap_android_wrapper.py')
if not (root/'android/gradlew').exists():
    warnings.append('gradlew not bundled. Run: python tool/bootstrap_android_wrapper.py')

# Firebase can be intentionally disabled for guest-mode Alpha.
gs=root/'android/app/google-services.json'
if gs.exists():
    try:
        data=json.loads(gs.read_text(encoding='utf-8'))
        if 'project_info' not in data: errors.append('google-services.json does not look like a real Firebase config')
    except Exception as e: errors.append(f'google-services.json invalid JSON: {e}')
else:
    warnings.append('Firebase guest mode: add real android/app/google-services.json and enable Google Services plugin for auth/sync.')

# Release signing must not remain debug for production.
app_gradle=(root/'android/app/build.gradle.kts').read_text(errors='ignore')
if 'signingConfig = signingConfigs.getByName("debug")' in app_gradle:
    warnings.append('Release still uses debug signing. Fine for Alpha only; replace before Play upload.')

print('Ziman v1.0 Alpha.4 preflight')
for w in warnings: print('WARN:',w)
for e in errors: print('ERROR:',e)
if errors: sys.exit(1)

ci = root / '.github/workflows/android_alpha_build.yml'
if not ci.exists():
    fail('Missing Android Alpha build workflow.')
else:
    ci_text = ci.read_text(encoding='utf-8')
    for required in ['flutter-version: \'3.47.0\'', 'flutter build apk --debug', 'bootstrap_android_wrapper.py']:
        if required not in ci_text:
            fail(f'Android build workflow missing: {required}')

print('PASS: static project structure/config checks passed.')
