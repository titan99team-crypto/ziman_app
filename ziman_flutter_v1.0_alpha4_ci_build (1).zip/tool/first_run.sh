#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo 'Flutter is not installed/in PATH'; exit 2; }
python tool/bootstrap_android_wrapper.py
flutter doctor -v
flutter pub get
python tool/preflight.py
flutter analyze
flutter test
printf '\nPASS: Ziman source checks completed.\n'
printf 'Next: start backend, then run:\nflutter run --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080\n'
