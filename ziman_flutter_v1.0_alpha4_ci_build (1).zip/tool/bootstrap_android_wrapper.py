#!/usr/bin/env python3
"""Hydrate Gradle wrapper files from the installed Flutter SDK template.

Why: wrapper binaries should come from a trusted local Flutter installation, not a
random copied JAR. This script creates a temporary Flutter Android project and
copies only the wrapper files into Ziman.
"""
from pathlib import Path
import shutil, subprocess, tempfile, sys

root = Path(__file__).resolve().parents[1]
flutter = shutil.which('flutter')
if not flutter:
    print('ERROR: flutter is not in PATH. Install Flutter stable first.')
    sys.exit(2)

with tempfile.TemporaryDirectory(prefix='ziman_flutter_wrapper_') as tmp:
    temp = Path(tmp) / 'wrapper_seed'
    subprocess.run([
        flutter, 'create', '--platforms=android', '--org', 'com.titan',
        '--project-name', 'ziman_wrapper_seed', str(temp)
    ], check=True)
    src_android = temp / 'android'
    dst_android = root / 'android'
    pairs = [
        ('gradlew', 'gradlew'),
        ('gradlew.bat', 'gradlew.bat'),
        ('gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.jar'),
    ]
    for src_rel, dst_rel in pairs:
        src = src_android / src_rel
        dst = dst_android / dst_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print('COPIED', dst_rel)
    (dst_android / 'gradlew').chmod(0o755)

print('PASS: Gradle wrapper hydrated from your installed Flutter SDK.')
print('NOTE: Ziman keeps its pinned gradle-wrapper.properties (Gradle 9.6.1).')
