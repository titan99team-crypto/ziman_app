$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter is not installed/in PATH' }
python tool/bootstrap_android_wrapper.py
flutter doctor -v
flutter pub get
python tool/preflight.py
flutter analyze
flutter test
Write-Host 'PASS: Ziman source checks completed.' -ForegroundColor Green
Write-Host 'Next: start backend, then run:'
Write-Host 'flutter run --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080'
