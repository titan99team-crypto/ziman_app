# Ziman v0.4 — Image OCR

- صفحة ترجمة صور فعلية بدل Placeholder.
- التقاط صورة بالكاميرا واختيار صورة من المعرض.
- معاينة الصورة داخل التطبيق.
- اختيار Iraqi / Sorani / Kurmanji كمصدر وهدف.
- OCR محلي باستخدام Tesseract.
- حزم `ara` و`kur` قابلة للتنزيل مرة واحدة والعمل بعدها Offline.
- Progress أثناء تنزيل الحزمة.
- تمرير OCR إلى HybridTranslationService.
- عرض النص المستخرج والترجمة ونسخهما.
- معالجة أخطاء الحزم وOCR برسائل واضحة.
- وثيقة بنية `IMAGE_OCR_ARCHITECTURE_AR.md`.

## حدود النسخة
- Online neural translation backend لم يُربط بعد.
- Sorani OCR الحالي baseline (`ara+kur`) ويجب قياسه على dataset حقيقي قبل إطلاقه تجارياً.
- Bounding-box overlay فوق الصورة لم يُنفذ بعد.
