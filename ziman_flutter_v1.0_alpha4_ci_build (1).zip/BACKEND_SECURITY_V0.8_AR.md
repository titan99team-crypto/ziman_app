# Ziman v0.8 — أمان الـBackend والمستخدمين

## ما تغير؟

هذه النسخة تجعل خادم Ziman هو مصدر الثقة للهوية والاستحقاقات والاستهلاك، وليس تطبيق الهاتف.

### 1) Firebase ID Token
بعد تسجيل المستخدم في Flutter يرسل التطبيق Firebase ID Token في:
`Authorization: Bearer <token>`

الخادم يتحقق منه عبر Firebase Admin SDK ويستخرج UID من الرمز الموقّع. لا يقبل UID مرسلاً من التطبيق داخل JSON كدليل هوية.

### 2) الترجمة المجانية وRate Limits
الترجمة تبقى متاحة للضيف. افتراضياً:
- الضيف: 6 طلبات/دقيقة و40/يوم.
- المستخدم المسجل: 20/دقيقة و250/يوم.

يمكن تغيير الحدود من متغيرات البيئة. في Production استخدم Redis لأن الذاكرة المحلية لا تعمل كعداد موحد عند وجود أكثر من نسخة Server.

### 3) الخصوصية في سجل الاستخدام
`usage_events` لا يخزن نص المستخدم ولا الترجمة. يسجل فقط: الزوج اللغوي، طول النص، نجاح الطلب، مصدر الترجمة، الحاجة للمراجعة، ومعرفاً مستعاراً HMAC.

### 4) شراء Google Play
مسار التحقق يتطلب مستخدماً مسجلاً. بعد أن تؤكد Google أن Purchase Token لمنتج `ziman_kurdish_course_full` في حالة PURCHASED:
1. يحسب الخادم SHA-256 للـPurchase Token.
2. يربط البصمة بحساب Firebase UID داخل `purchase_tokens`.
3. يمنع نفس الشراء من الارتباط بحساب Ziman مختلف.
4. يكتب `users/{uid}/entitlements/course_full` من Admin SDK.
5. يحدث `users/{uid}.course_full=true` للتوافق مع واجهة v0.7.

العميل لا يملك صلاحية كتابة entitlement أو purchase_tokens من Firestore Rules.

### 5) الأسرار
لا تضع في Flutter:
- OPENAI_API_KEY
- Firebase Admin service account
- Google Play service account
- Redis password
- مفاتيح HMAC

تكون كلها في Server/Secret Manager فقط.

## تشغيل محلي
1. انسخ `.env.example` إلى `.env` واملأ القيم.
2. `pip install -r requirements.txt`
3. شغّل Redis أو اترك REDIS_URL فارغاً للتطوير فقط.
4. `uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload`

## Production
يفضل Cloud Run أو خدمة مشابهة + Redis مُدار + Secret Manager + HTTPS فقط. إذا كنت خلف Proxy موثوق وتحتاج X-Forwarded-For فعّل `ZIMAN_TRUST_PROXY_HEADERS=1` فقط عندما تعرف أن الوصول المباشر للخادم محجوب أو أن الـProxy ينظف هذا الهيدر.
