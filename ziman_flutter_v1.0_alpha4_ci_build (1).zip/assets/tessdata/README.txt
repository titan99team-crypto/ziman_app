Ziman downloads ara.traineddata and kur.traineddata on demand at runtime.
For production, host versioned/checksummed copies on the Ziman CDN.
