# Ziman v0.7 — الحساب والمزامنة

## ما تم بناؤه
- تسجيل دخول Google عبر Firebase Auth.
- تسجيل دخول برقم الهاتف وOTP.
- صفحة Profile وحالة الكورس ولغة التعلم المفضلة.
- ملف مستخدم داخل Firestore: `users/{uid}`.
- تقدم التعلم داخل `users/{uid}/learning/progress`.
- إرسال Firebase ID Token إلى Backend عند التحقق من شراء Google Play حتى يمكن ربط الاستحقاق بالحساب.
- وضع Guest يبقى متاحاً إذا لم يتم إعداد Firebase بعد.

## إعداد Firebase الفعلي
1. أنشئ مشروع Firebase باسم Ziman.
2. فعّل Authentication > Google و Phone.
3. أضف تطبيق Android بنفس package name النهائي.
4. ضع `google-services.json` في `android/app/`.
5. شغّل:
   `dart pub global activate flutterfire_cli`
   ثم `flutterfire configure`.
6. فعّل Cloud Firestore وانشر القواعد الموجودة في `firebase/firestore.rules`.
7. أضف SHA-1 و SHA-256 لتطبيق Android داخل Firebase حتى يعمل Google Sign-In وPhone Auth بشكل صحيح.

## أمان مهم
حقل `course_full` يجب ألا يسمح التطبيق للمستخدم بتغييره بنفسه. في الإنتاج، Backend بعد التحقق من Google Play هو الذي يكتب الاستحقاق باستخدام Firebase Admin SDK. قواعد Firestore في هذا المشروع تمنع العميل من تغيير `course_full`.

## المزامنة
عند تسجيل الدخول يمكن دمج التقدم المحلي مع السحابي باختيار الأعلى لكل Score وعدم حذف أي درس مكتمل. هذه السياسة تمنع خسارة تقدم المستخدم عندما يبدل الجهاز أو يستخدم التطبيق كضيف ثم يسجل دخوله.
