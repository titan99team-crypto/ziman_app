# Ziman v0.9 — UX & Commercial Readiness

- Splash وOnboarding يظهر مرة واحدة.
- Light/Dark/System theme.
- Settings موحدة.
- Privacy/Terms كمسودات داخل التطبيق مع تنبيه واضح للمراجعة القانونية قبل النشر.
- مراقبة حالة الشبكة بدون افتراض أن وجود Wi‑Fi يعني وجود إنترنت فعلي.
- شاشة حدود الاستخدام Online عبر endpoint لا يستهلك الحصة.
- صفحة Offline Downloads حقيقية لحزم OCR مع تنزيل/حذف وتقدم.
- حزم ترجمة Offline تظهر كـ pending إلى حين توفر ملفات النماذج النهائية.
- Analytics وPush Notifications غير مفعلة افتراضياً؛ الموجود فقط تفضيلات محلية.
- تحديث Backend إلى 0.9 وإضافة GET /v1/usage/status.
