# iOS setup for Ziman voice

After generating the iOS shell, add to `ios/Runner/Info.plist`:

```xml
<key>NSMicrophoneUsageDescription</key>
<string>Ziman needs microphone access to translate spoken phrases.</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>Ziman uses speech recognition to turn your spoken phrase into text for translation.</string>
```

The actual supported recognition/TTS locales depend on iOS and installed voices. Ziman checks capabilities at runtime rather than assuming Kurdish voice support.
