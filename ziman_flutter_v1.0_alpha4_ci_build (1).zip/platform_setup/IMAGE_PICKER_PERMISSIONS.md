# صلاحيات الصور والكاميرا

## Android
`image_picker` الحديث يستخدم Android Photo Picker على الإصدارات المناسبة. الكاميرا الفعلية تحتاج تطبيق Camera متوفراً على الجهاز. عند إنشاء مشروع Android الكامل بـ Flutter راجع manifest إذا أضفت أي سلوك Camera مخصص.

## iOS Info.plist
أضف:
- `NSCameraUsageDescription`: يستخدم Ziman الكاميرا لالتقاط النص وترجمته.
- `NSPhotoLibraryUsageDescription`: يستخدم Ziman الصور التي تختارها لاستخراج النص وترجمته.
