# Android setup for Ziman voice

After generating the Android shell (`flutter create .` if this source tree does not yet contain `/android`), add these permissions inside `android/app/src/main/AndroidManifest.xml` directly under `<manifest ...>`:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

For Android 11+ speech recognition package visibility, also add inside `<manifest>`:

```xml
<queries>
    <intent>
        <action android:name="android.speech.RecognitionService" />
    </intent>
    <intent>
        <action android:name="android.intent.action.TTS_SERVICE" />
    </intent>
</queries>
```

Notes:
- `speech_to_text` requests microphone permission through the platform recognizer, but the manifest permission is still required.
- Recognition quality and offline availability depend on the speech engine and downloaded language packs installed on the phone.
- Ziman does not assume that Sorani or Kurmanji voice support exists on every phone; the app checks available locales first.
