import 'package:flutter_test/flutter_test.dart';
import 'package:ziman/services/text_normalizer.dart';

void main() {
  final normalizer = TextNormalizer();

  test('normalizes Arabic variants and whitespace', () {
    final value = normalizer.normalize('  شـلـونــك؟  ');
    expect(value, isNotEmpty);
    expect(value.contains('  '), isFalse);
  });

  test('normalization is deterministic', () {
    const input = 'هسه وين رايح؟';
    expect(normalizer.normalize(input), normalizer.normalize(input));
  });
}
