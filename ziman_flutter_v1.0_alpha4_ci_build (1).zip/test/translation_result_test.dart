import 'package:flutter_test/flutter_test.dart';
import 'package:ziman/models/translation_result.dart';

void main() {
  test('translation result can represent offline-safe metadata', () {
    const result = TranslationResult(
      primary: 'سڵاو',
      confidence: 0.9,
      source: 'local-dialect-db',
      needsReview: false,
    );
    expect(result.primary, 'سڵاو');
    expect(result.confidence, greaterThan(0.8));
    expect(result.needsReview, isFalse);
  });
}
