# Ziman v0.9 — ملاحظات الإصدار

هذه النسخة تركز على تجربة الاستخدام والجاهزية التجارية، وليست Release نهائية للمتجر بعد.

## ما تم تنفيذه
- Splash Screen وهوية Ziman أولية.
- Onboarding من 5 شاشات يظهر مرة واحدة.
- Light / Dark / System Theme مع حفظ الاختيار.
- Settings موحدة.
- تنبيه حالة الشبكة بدون افتراض أن الاتصال يضمن الإنترنت.
- شاشة Usage تعرض حصة الدقيقة واليوم من الـBackend بدون استهلاك الحصة.
- صفحة Offline Downloads فعلية لحزم Tesseract OCR (ara / kur): تنزيل، تقدم، حذف، حالة تثبيت.
- توضيح منفصل لحزم الترجمة العصبية Offline بأنها غير منشورة بعد.
- Privacy Policy وTerms كمسودات داخلية واضحة وليست نصوصاً قانونية نهائية.
- Analytics وPush Notifications غير مفعلة؛ يوجد فقط Opt-in محلي جاهز للمستقبل.
- تحديث Backend إلى 0.9 وإضافة GET /v1/usage/status.
- Dark theme متكامل مع Material 3.

## تحقق تم تنفيذه
- Python backend يجتاز compileall بلا أخطاء Syntax.
- لم يتم Flutter build لأن Flutter SDK غير موجود في بيئة العمل الحالية.

## قبل Play Store
راجع COMMERCIAL_READINESS_V0.9_AR.md.
