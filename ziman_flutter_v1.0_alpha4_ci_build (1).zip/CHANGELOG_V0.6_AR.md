# Ziman 0.6.0
- صفحة تعلم جديدة بالكامل.
- 3 مستويات تعليمية وبنية قابلة للتوسع.
- جمل عراقية ↔ سوراني ↔ كرمانجي.
- محادثات واختبارات.
- حفظ الإنجاز والدرجات محلياً.
- Google Play one-time purchase للكورس.
- Restore purchases.
- Server-side entitlement verification contract.
