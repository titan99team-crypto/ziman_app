# Ziman v0.7
- Firebase bootstrap مع Guest fallback.
- Google Sign-In وفق API الحديث لـ google_sign_in 7.x.
- Phone OTP عبر Firebase Auth.
- Profile page جديدة.
- Firestore user/profile schema.
- Cloud progress sync service.
- Firebase ID token مضاف لطلب التحقق من شراء الكورس.
- قواعد Firestore تمنع المستخدم من منح نفسه course_full.
