# Ziman v1.0 Alpha.2 — أول تشغيل فعلي

هذه الحزمة تصلح مشكلة مهمة في Alpha.1: ملفات Gradle Wrapper الثنائية لم تكن موجودة. بدلاً من شحن JAR مجهول المصدر، أضفنا أداة تولّد wrapper من نسخة Flutter المثبتة عندك ثم تحتفظ بإعداد Ziman المثبت على Gradle 9.6.1.

## المتطلبات
- Flutter 3.47 Stable.
- Android Studio + Android SDK 36.
- JDK 17 أو إصدار متوافق مع Flutter/AGP.
- Python 3 لتشغيل فحوص المشروع.

## Windows
من PowerShell داخل مجلد المشروع:
```powershell
powershell -ExecutionPolicy Bypass -File tool/first_run.ps1
```

## macOS / Linux
```bash
bash tool/first_run.sh
```

السكريبت يقوم بـ:
1. إنشاء مشروع Flutter مؤقت موثوق.
2. نسخ `gradlew`, `gradlew.bat`, و`gradle-wrapper.jar` فقط.
3. `flutter doctor -v`.
4. `flutter pub get`.
5. فحص Ziman static preflight.
6. `flutter analyze`.
7. `flutter test`.

## Firebase
يمكن تشغيل Alpha كضيف بدون Firebase. لتفعيل الحسابات:
1. ضع `android/app/google-services.json` الحقيقي.
2. فك تعليق `id("com.google.gms.google-services")` داخل `android/app/build.gradle.kts`.
3. شغّل `flutterfire configure` وأضف SHA-1 / SHA-256 في Firebase.

## تشغيل التطبيق
بعد تشغيل Backend:
```bash
flutter run --dart-define=ZIMAN_API_BASE_URL=http://10.0.2.2:8080
```
`10.0.2.2` خاص بمحاكي Android. على هاتف حقيقي استخدم HTTPS backend أو عنوان جهاز التطوير داخل الشبكة أثناء الاختبار.

## مهم
Release build ما زال يستخدم debug signing كحاجز واضح يمنع اعتبار Alpha نسخة متجر. قبل Google Play يجب إنشاء Upload Key حقيقي وتحديث signing config.
